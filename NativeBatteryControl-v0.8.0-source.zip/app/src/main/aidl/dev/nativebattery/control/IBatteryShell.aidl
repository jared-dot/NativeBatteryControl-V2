package dev.nativebattery.control;
interface IBatteryShell {
    String readSetting(String pkg, String setting) = 0;
    String writeSetting(String pkg, String setting, String value) = 1;
    void destroy() = 16777114;
}
