package dev.nativebattery.control;
import android.content.*;
import java.util.*;
import java.util.function.BooleanSupplier;

final class ReapplyEngine {
    static final class Pending {String pkg,setting,wanted,id;int first;Pending(String p,String s,String w,int f,String i){pkg=p;setting=s;wanted=w;first=f;id=i;}}
    static String run(Context c,IBatteryShell svc,BooleanSupplier keepGoing){
        int same=0,applied=0,failed=0,skipped=0;StringBuilder notes=new StringBuilder();List<Pending> pending=new ArrayList<>();Set<String> widgets=new HashSet<>();boolean widgetsKnown=false;
        try{String raw=svc.readSetting("android","widgets");if(raw!=null&&raw.startsWith("OK\n")){widgetsKnown=true;widgets.addAll(Arrays.asList(raw.substring(3).split("\\R")));}}catch(Exception ignored){}
        Map<String,Map<String,String>> targets=Profiles.all(c);
        outer:for(String setting:Profiles.KEYS){
          for(Map.Entry<String,Map<String,String>> app:targets.entrySet()){
            String pkg=app.getKey();if(!keepGoing.getAsBoolean())break outer;
            String wanted=app.getValue().get(setting);if(wanted==null)continue; if(ToolStore.blocked(c,pkg)){skipped++;continue;}
            try{c.getPackageManager().getApplicationInfo(pkg,0);}catch(Exception e){skipped++;notes.append(pkg).append(": not installed / not visible\n");continue;}
            if(!keepGoing.getAsBoolean())break outer;
                try{synchronized(Profiles.WRITE_LOCK){if(!keepGoing.getAsBoolean())break outer;if(ToolStore.blocked(c,pkg)||!wanted.equals(Profiles.get(c,pkg,setting))){skipped++;continue;}String actual=svc.readSetting(pkg,setting);String skip=EnforcementPolicy.skip(setting,wanted,actual,widgets.contains(pkg));if(skip==null&&setting.equals("bucket")&&!widgetsKnown&&!wanted.equals("active"))skip="Widget status unavailable";if(skip!=null){if(skip.equals("Already matches"))same++;else{skipped++;notes.append(pkg).append(" / ").append(setting).append(": ").append(skip).append('\n');}continue;}if(!keepGoing.getAsBoolean())break outer;String id=ToolStore.begin(c,pkg,setting,actual,wanted,wanted,"Reapply");String write=svc.writeSetting(pkg,setting,wanted);if(write==null||!write.startsWith("OK\n")){ToolStore.finish(c,id,"Command failed",null);failed++;notes.append(pkg).append(" / ").append(setting).append(": command failed\n");continue;}int first=Verification.compare(setting,wanted,svc.readSetting(pkg,setting));pending.add(new Pending(pkg,setting,wanted,first,id));}}
                catch(Exception e){failed++;notes.append(pkg).append(" / ").append(setting).append(": ").append(e.getClass().getSimpleName()).append('\n');}
            }
        }
        if(!pending.isEmpty()&&keepGoing.getAsBoolean())try{Thread.sleep(5000);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        for(Pending p:pending){if(!keepGoing.getAsBoolean()||!p.wanted.equals(Profiles.get(c,p.pkg,p.setting))){skipped++;continue;}try{String raw=svc.readSetting(p.pkg,p.setting);int last=Verification.compare(p.setting,p.wanted,raw);ToolStore.finish(c,p.id,Verification.result(true,p.first,last),raw);if(last==Verification.MATCH)applied++;else{failed++;notes.append(p.pkg).append(" / ").append(p.setting).append(": ").append(Verification.result(true,p.first,last)).append('\n');}}catch(Exception e){failed++;notes.append(p.pkg).append(" / ").append(p.setting).append(": verification unavailable\n");}}
        return (keepGoing.getAsBoolean()?"Reapplication finished":"Reapplication interrupted")+"\n"+same+" already matched • "+applied+" reapplied • "+failed+" failed/unverified • "+skipped+" skipped"+(notes.length()>0?"\n\n"+notes:"");
    }
}
