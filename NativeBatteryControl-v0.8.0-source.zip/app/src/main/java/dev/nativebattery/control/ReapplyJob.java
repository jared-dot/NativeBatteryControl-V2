package dev.nativebattery.control;

import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import rikka.shizuku.Shizuku;

/** Only runs when scheduled; no foreground service or ongoing wake lock. */
public class ReapplyJob extends JobService {
    private final Handler main=new Handler(Looper.getMainLooper());
    private Run current;
    private final class Run {
        final JobParameters params;volatile boolean active=true;boolean bound,started;Thread thread;
        final Shizuku.UserServiceArgs args=new Shizuku.UserServiceArgs(new ComponentName(ReapplyJob.this,BatteryShell.class)).tag("native_battery_reapply").processNameSuffix("battery_reapply").daemon(false).version(8);
        final Shizuku.OnBinderReceivedListener listener=()->main.post(()->tryBind(this));
        final Runnable timeout=()->finish(this,"Skipped: Shizuku connection unavailable.");
        final ServiceConnection connection=new ServiceConnection(){
            public void onServiceConnected(ComponentName n,IBinder b){if(current!=Run.this||!active||started)return;started=true;main.removeCallbacks(timeout);IBatteryShell svc=IBatteryShell.Stub.asInterface(b);thread=new Thread(()->{String result;try{result=ReapplyEngine.run(ReapplyJob.this,svc,()->active&&!Profiles.foreground&&Profiles.interval(ReapplyJob.this)>0&&!Thread.currentThread().isInterrupted());}catch(Exception e){result="Reapplication failed: "+e;}final String report=result;main.post(()->finish(Run.this,report));},"battery-reapply");thread.start();}
            public void onServiceDisconnected(ComponentName n){finish(Run.this,"Skipped/interrupted: Shizuku disconnected.");}
        };
        Run(JobParameters p){params=p;}
    }
    @Override public boolean onStartJob(JobParameters p){if(Profiles.interval(this)<=0||Profiles.all(this).isEmpty()||Profiles.foreground)return false;Run r=new Run(p);current=r;main.postDelayed(r.timeout,15000);Shizuku.addBinderReceivedListenerSticky(r.listener);tryBind(r);return true;}
    private void tryBind(Run r){if(current!=r||!r.active||r.bound)return;if(Profiles.foreground||Profiles.interval(this)<=0){finish(r,"Skipped: foreground or disabled.");return;}try{if(!Shizuku.pingBinder())return;if(Shizuku.getVersion()<12||Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED){finish(r,"Skipped: Shizuku authorization required.");return;}r.bound=true;Shizuku.bindUserService(r.args,r.connection);}catch(Exception e){finish(r,"Skipped: "+e);}}
    private void cleanup(Run r){r.active=false;main.removeCallbacks(r.timeout);Shizuku.removeBinderReceivedListener(r.listener);if(r.thread!=null)r.thread.interrupt();if(r.bound)try{Shizuku.unbindUserService(r.args,r.connection,true);}catch(Exception ignored){}if(current==r)current=null;}
    private void finish(Run r,String message){if(current!=r||!r.active)return;cleanup(r);Profiles.record(this,message);jobFinished(r.params,false);}
    @Override public boolean onStopJob(JobParameters p){if(current!=null&&current.params==p)cleanup(current);return false;}
    @Override public void onDestroy(){if(current!=null)cleanup(current);super.onDestroy();}
}
