package dev.nativebattery.control;
import java.util.*;
/** Conservative reversible values and diagnostic deltas. */
final class ToolPolicy {
 static String previous(String key,String raw){
  String v=Verification.value(raw);
  if(key.equals("bucket")){switch(v){case "10":return "active";case "20":return "working_set";case "30":return "frequent";case "40":return "rare";case "45":return "restricted";default:return null;}}
  if(key.equals("doze"))return v.equals("User exempt")?"add":v.equals("Not exempt")||v.equals("System except-idle only")?"remove":null;
  String mode=Verification.mode(raw);return mode.startsWith("default (")?"default":Arrays.asList("allow","ignore","default").contains(mode)?mode:null;
 }
 static String extractMode(String raw,String key){
  if(raw==null||!raw.startsWith("OK\n")||(!key.equals("RUN_ANY_IN_BACKGROUND")&&!key.equals("RUN_IN_BACKGROUND")))return null;
  StringBuilder b=new StringBuilder("OK\n");for(String line:raw.substring(3).split("\\R"))if(line.trim().matches("(?i)(?:Uid mode:\\s*)?"+key+":\\s*[a-z_]+.*"))b.append(line).append('\n');
  return b.length()==3?null:b.toString();
 }
 static double delta(double before,double after){return BatteryDiagnostics.known(before)&&BatteryDiagnostics.known(after)&&after>=before?after-before:Double.NaN;}
 static boolean comparable(BatteryDiagnostics a,BatteryDiagnostics b,long elapsed,long wall){return elapsed>0&&Math.abs(wall-elapsed)<=60000&&BatteryDiagnostics.known(a.device[10])&&a.device[10]>0&&a.device[10]==b.device[10]&&BatteryDiagnostics.known(delta(a.device[2],b.device[2]));}
 static boolean idle(BatteryDiagnostics a,BatteryDiagnostics b,long elapsed,long wall){return comparable(a,b,elapsed,wall)&&a.device[11]==0&&b.device[11]==0&&Math.abs(delta(a.device[2],b.device[2])-elapsed)<Math.max(5000,elapsed*.02)&&BatteryDiagnostics.known(delta(a.device[3],b.device[3]))&&delta(a.device[3],b.device[3])<=Math.max(60000,elapsed*.02);}
 static Map<String,String> preset(int i){Map<String,String> m=new LinkedHashMap<>();m.put("doze",i==0?"add":"remove");m.put("RUN_ANY_IN_BACKGROUND",i==2?"ignore":"allow");m.put("RUN_IN_BACKGROUND",i==2?"ignore":"allow");if(i!=0)m.put("bucket",i==2?"restricted":"working_set");return m;}
}
