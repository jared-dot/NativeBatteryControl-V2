package dev.nativebattery.control;

import android.app.job.*;
import android.content.*;
import java.util.*;

/** Saved desired values are opt-in, independent of Android's actual state. */
final class Profiles {
    static final String[] KEYS={"doze","RUN_ANY_IN_BACKGROUND","RUN_IN_BACKGROUND","bucket"};
    static final int JOB=6060;
    static volatile boolean foreground;
    static final Object WRITE_LOCK=new Object();
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("desired_battery_v6",Context.MODE_PRIVATE);}
    static SharedPreferences targets(Context c){return c.getSharedPreferences("desired_targets_v6",Context.MODE_PRIVATE);}
    static String key(String pkg,String setting){return pkg+"|"+setting;}
    static String get(Context c,String pkg,String setting){return targets(c).getString(key(pkg,setting),null);}
    static void save(Context c,String pkg,String setting,String value){if(EnforcementPolicy.valid(pkg,setting,value))targets(c).edit().putString(key(pkg,setting),value).apply();}
    static void remove(Context c,String pkg,String setting){targets(c).edit().remove(key(pkg,setting)).apply();}
    static void forget(Context c,String pkg){SharedPreferences.Editor e=targets(c).edit();for(String k:KEYS)e.remove(key(pkg,k));e.apply();}
    static SortedMap<String,Map<String,String>> all(Context c){SortedMap<String,Map<String,String>> out=new TreeMap<>();for(Map.Entry<String,?> e:targets(c).getAll().entrySet()){String[] p=e.getKey().split("\\|",-1);if(p.length==2&&e.getValue() instanceof String&&EnforcementPolicy.valid(p[0],p[1],(String)e.getValue()))out.computeIfAbsent(p[0],k->new HashMap<>()).put(p[1],(String)e.getValue());}return out;}
    static int interval(Context c){return prefs(c).getInt("interval",0);}
    static String mode(Context c){int n=interval(c);return n==0?"Off — manual only":n==-1?"When opening the app": "Every "+n+" minutes (approx.)";}
    static boolean setInterval(Context c,int n){if(n!=0&&n!=-1&&n!=15&&n!=30&&n!=60)return false;prefs(c).edit().putInt("interval",n).apply();JobScheduler js=c.getSystemService(JobScheduler.class);js.cancel(JOB);if(n<=0)return true;try{int r=js.schedule(new JobInfo.Builder(JOB,new ComponentName(c,ReapplyJob.class)).setPeriodic(n*60000L).setPersisted(true).build());if(r==JobScheduler.RESULT_SUCCESS)return true;}catch(Exception ignored){}prefs(c).edit().putInt("interval",0).apply();return false;}
    static void record(Context c,String message){prefs(c).edit().putString("last",new java.text.SimpleDateFormat("MMM d, HH:mm:ss",Locale.getDefault()).format(new Date())+"\n"+message).apply();}
    static String last(Context c){return prefs(c).getString("last","No reapplication run yet.");}
}
