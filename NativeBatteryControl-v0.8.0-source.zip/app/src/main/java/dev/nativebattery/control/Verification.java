package dev.nativebattery.control;

import java.util.*;
import java.util.regex.*;

/** Pure parsers and comparisons, shared by the UI and host-side tests. */
final class Verification {
    static final int MATCH=1, MISMATCH=0, UNKNOWN=-1;
    static String value(String raw) { return raw!=null&&raw.startsWith("OK\n")?raw.substring(3).trim():"Unknown"; }
    static String mode(String raw) {
        String v=value(raw);
        Matcher m=Pattern.compile("(?im)^\\s*(?:Uid mode:\\s*)?(?:RUN_ANY_IN_BACKGROUND|RUN_IN_BACKGROUND):\\s*([a-z_]+)").matcher(v);
        String first=null;
        while(m.find()){String found=m.group(1);if(first==null)first=found;else if(!first.equals(found))return "Mixed";}
        if(first!=null)return first;
        Matcher def=Pattern.compile("(?i)Default mode:\\s*([a-z_]+)").matcher(v);
        return def.find()?"default ("+def.group(1)+")":"Unknown";
    }
    static String expected(String setting,String request) {
        if(setting.equals("bucket"))switch(request){case "active":return "10";case "working_set":return "20";case "frequent":return "30";case "rare":return "40";case "restricted":return "45";}
        if(setting.equals("doze"))return request.equals("add")?"Full exemption":"No full exemption";
        if(setting.equals("force_stop"))return "stopped=true";
        return request;
    }
    static int compare(String setting,String request,String raw) {
        String actual=value(raw);
        if(actual.equals("Unknown")||actual.isEmpty())return UNKNOWN;
        if(setting.equals("bucket"))return actual.matches("\\d+")?(actual.equals(expected(setting,request))?MATCH:MISMATCH):UNKNOWN;
        if(setting.equals("doze")){
            boolean exempt=actual.equals("User exempt")||actual.startsWith("System exempt");
            if(!exempt&&!actual.equals("Not exempt")&&!actual.equals("System except-idle only"))return UNKNOWN;
            return exempt==request.equals("add")?MATCH:MISMATCH;
        }
        if(setting.equals("force_stop"))return actual.equals("stopped=true")?MATCH:actual.equals("stopped=false")?MISMATCH:UNKNOWN;
        String m=mode(raw);if(m.equals("Unknown"))return UNKNOWN;
        return m.equals(request)||(request.equals("default")&&m.startsWith("default ("))?MATCH:MISMATCH;
    }
    static String result(boolean commandOk,int first,int last){
        if(!commandOk)return "Command failed";
        if(last==UNKNOWN)return "Could not verify";
        if(last==MATCH)return "Applied successfully";
        if(first==MATCH)return "Applied, then reverted";
        return "Not applied";
    }
    /** Only actual bound provider records in the Widgets section, never the provider catalog. Null = unreadable. */
    static Set<String> widgets(String raw) {
        if(raw==null||!raw.startsWith("OK\n"))return null;
        Set<String> found=new HashSet<>();boolean inside=false,complete=false,unrecognized=false;
        Pattern p=Pattern.compile("^provider=ProviderId\\{user:\\s*(\\d+),.*?cmp:\\s*(?:ComponentInfo\\{)?([A-Za-z][A-Za-z0-9_.]*)/.*$");
        for(String line:value(raw).split("\\R")){
            String s=line.trim();if(s.equals("Widgets:")){inside=true;continue;}if(!inside)continue;
            if(s.equals("Hosts:")){complete=true;break;}
            if(s.startsWith("provider=")){Matcher m=p.matcher(s);if(!m.matches()){unrecognized=true;continue;}if(m.group(1).equals("0"))found.add(m.group(2));}
        }
        return complete&&!unrecognized?found:null;
    }
}
