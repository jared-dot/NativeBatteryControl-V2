package dev.nativebattery.control;

import java.util.*;
import java.util.regex.*;

/** Read-only parser. Missing fields remain NaN; never estimate background energy from time. */
public final class BatteryDiagnostics {
    public static final String[] METRICS={"Estimated energy","Background energy","Partial wakelocks","Background wakelocks","CPU time","Wakeup alarms","Job starts","Foreground activity","Foreground services","Foreground energy","Wi-Fi scan time"};
    public static final String[] DEVICE={"Battery level","Temperature (°C)","Time on battery","Screen-on time","Screen-off time","Screen-off awake","Screen-on discharge","Screen-off discharge","Deep Doze time","Mobile radio active","Stats start (epoch ms)","Powered","Deep Doze entries","Light Doze entries","Light Doze time","Wi-Fi controller scan time"};
    public static final int POWER=0,BG=1,WAKE=2,BGWAKE=3,CPU=4,ALARMS=5,JOBS=6,FG=7,FGS=8,FGPOWER=9,WIFI=10;
    public final TreeMap<Integer,double[]> uids=new TreeMap<>();
    public final double[] device=missing(DEVICE.length);
    public String note="";
    public static double[] missing(int n){double[] a=new double[n];Arrays.fill(a,Double.NaN);return a;}
    public static boolean known(double d){return Double.isFinite(d)&&d>=0;}
    private double[] uid(int id){return uids.computeIfAbsent(id,k->missing(METRICS.length));}
    private static double number(String s){try{double d=Double.parseDouble(s.trim());return known(d)?d:Double.NaN;}catch(Exception e){return Double.NaN;}}
    private static double field(List<String> a,int i){return i<a.size()?number(a.get(i)):Double.NaN;}
    private static double sum(double a,double b){return known(a)&&known(b)?a+b:Double.NaN;}
    private static void add(double[] a,int i,double v){if(known(v))a[i]=(known(a[i])?a[i]:0)+v;}
    static List<String> csv(String l){List<String> a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean quote=false;for(int i=0;i<l.length();i++){char c=l.charAt(i);if(c=='"'){if(quote&&i+1<l.length()&&l.charAt(i+1)=='"'){b.append(c);i++;}else quote=!quote;}else if(c==','&&!quote){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a;}
    static int uidNumber(String s){try{if(s.matches("\\d+"))return Integer.parseInt(s);Matcher m=Pattern.compile("u(\\d+)([as])(\\d+)").matcher(s);if(m.matches())return Integer.parseInt(m.group(1))*100000+(m.group(2).equals("a")?10000:0)+Integer.parseInt(m.group(3));}catch(Exception ignored){}return -1;}
    private static String body(String raw){return raw!=null&&raw.startsWith("OK\n")?raw.substring(3):"";}
    private static final String NUM="([0-9]+(?:\\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)";
    public static BatteryDiagnostics parse(String battery,String checkin,String human){BatteryDiagnostics d=new BatteryDiagnostics();
        String b=body(battery),c=body(checkin),h=body(human);
        Matcher level=Pattern.compile("(?m)^\\s*level:\\s*(\\d+)\\s*$").matcher(b);if(level.find())d.device[0]=number(level.group(1));
        Matcher temp=Pattern.compile("(?m)^\\s*temperature:\\s*(-?\\d+)\\s*$").matcher(b);if(temp.find())d.device[1]=Double.parseDouble(temp.group(1))/10;
        Matcher plug=Pattern.compile("(?mi)^\\s*(?:AC|USB|Wireless|Dock) powered:\\s*(true|false)\\s*$").matcher(b);boolean seen=false,connected=false;while(plug.find()){seen=true;connected|=plug.group(1).equalsIgnoreCase("true");}if(seen)d.device[11]=connected?1:0;
        boolean anyCurrent=false;for(String line:c.split("\\R")){List<String> f=csv(line);if(f.size()<5||!f.get(0).equals("9")||!f.get(2).equals("l"))continue;int id=uidNumber(f.get(1));if(id<0)continue;anyCurrent=true;String tag=f.get(3);if(id==0){switch(tag){case "bt":d.device[2]=field(f,5);d.device[4]=field(f,10);d.device[10]=field(f,9);double up=field(f,11);if(known(up))d.device[5]=up;if(!known(d.device[3])&&known(d.device[2])&&known(d.device[4])&&d.device[2]>=d.device[4])d.device[3]=d.device[2]-d.device[4];break;case "dc":d.device[6]=field(f,6);d.device[7]=field(f,7);break;case "m":d.device[9]=field(f,8);d.device[8]=field(f,13);d.device[12]=field(f,14);d.device[13]=field(f,20);d.device[14]=field(f,19);double screen=field(f,4);if(known(screen))d.device[3]=screen;break;default:break;}continue;}
            switch(tag){case "pwi":if(f.get(4).equals("uid"))d.uid(id)[POWER]=field(f,5);break;case "awl":d.uid(id)[WAKE]=field(f,4);d.uid(id)[BGWAKE]=field(f,5);break;case "cpu":d.uid(id)[CPU]=sum(field(f,4),field(f,5));break;case "wua":add(d.uid(id),ALARMS,field(f,5));break;case "jb":add(d.uid(id),JOBS,field(f,6));break;case "fg":d.uid(id)[FG]=field(f,4);break;case "fgs":d.uid(id)[FGS]=field(f,4);break;case "wfl":d.uid(id)[WIFI]=field(f,5);break;default:break;}}
        // Android's human-readable energy section explicitly labels UID and process-state energy.
        boolean energy=false;Pattern u=Pattern.compile("^\\s*Uid\\s+(\\S+):\\s*"+NUM+"(?:\\s+mAh)?(.*)$",Pattern.CASE_INSENSITIVE);Pattern bg=Pattern.compile("(?:^|\\s)(?:bg|background):\\s*"+NUM+"(?:\\s|$)",Pattern.CASE_INSENSITIVE);
        for(String line:h.split("\\R")){if(line.toLowerCase(Locale.ROOT).contains("estimated power use (mah)")){energy=true;continue;}if(!energy)continue;Matcher m=u.matcher(line);if(m.matches()){int id=uidNumber(m.group(1));if(id<0)continue;double[] a=d.uid(id);double p=number(m.group(2));if(known(p))a[POWER]=p;String tail=m.group(3).split("\\(",2)[0];Matcher fm=Pattern.compile("(?:^|\\s)(?:fg|foreground):\\s*"+NUM+"(?:\\s|$)",Pattern.CASE_INSENSITIVE).matcher(tail);if(fm.find()){double v=number(fm.group(1));if(known(v)&&known(p)&&v<=p+.01)a[FGPOWER]=v;}Matcher bm=bg.matcher(tail);if(bm.find()){double v=number(bm.group(1));if(known(v)&&known(p)&&v<=p+.01)a[BG]=v;}}}
        // Prefer explicit textual Doze and radio timings when available.
        for(String line:h.split("\\R")){String t=line.trim();if(t.startsWith("Device deep doze time:"))d.device[8]=duration(t.substring(t.indexOf(':')+1));else if(t.startsWith("Wi-Fi Scan time:")||t.startsWith("Wifi Scan time:"))d.device[15]=duration(t.substring(t.indexOf(':')+1));else if(t.startsWith("Mobile radio active time:")){double v=duration(t.substring(t.indexOf(':')+1));if(known(v))d.device[9]=v;}}
        d.note=(anyCurrent?"Android current statistics":"Current check-in format not recognized")+(energy?"; native UID energy section found":"; energy section unavailable")+(b.isEmpty()?"; battery status unavailable":"");return d;
    }
    static double duration(String s){Matcher m=Pattern.compile("(\\d+)\\s*(ms|d|h|m|s)\\b").matcher(s.split("\\(",2)[0]);double total=0;boolean seen=false;while(m.find()){seen=true;long scale;switch(m.group(2)){case "d":scale=86400000;break;case "h":scale=3600000;break;case "m":scale=60000;break;case "s":scale=1000;break;default:scale=1;}total+=Double.parseDouble(m.group(1))*scale;}return seen?total:Double.NaN;}
    public String encode(){StringBuilder s=new StringBuilder("NOTE\t").append(note.replace('\n',' ')).append('\n');append(s,"DEVICE",device);for(Map.Entry<Integer,double[]> e:uids.entrySet())append(s,Integer.toString(e.getKey()),e.getValue());return s.toString();}
    private static void append(StringBuilder s,String label,double[] a){s.append(label);for(double v:a)s.append('\t').append(v);s.append('\n');}
    public static BatteryDiagnostics decode(String raw){BatteryDiagnostics d=new BatteryDiagnostics();if(raw==null||!raw.startsWith("OK\n")){d.note="Diagnostic read failed: "+raw;return d;}for(String line:raw.substring(3).split("\n")){String[] a=line.split("\t",-1);if(a.length<2)continue;if(a[0].equals("NOTE")){d.note=a[1];continue;}double[] dest;if(a[0].equals("DEVICE"))dest=d.device;else{int id=uidNumber(a[0]);if(id<0)continue;dest=d.uid(id);}if(a.length!=dest.length+1)continue;for(int i=0;i<dest.length;i++)try{dest[i]=Double.parseDouble(a[i+1]);}catch(Exception ignored){}}return d;}
    public static String time(double v){if(!known(v))return "Unavailable";long min=(long)(v/60000),sec=(long)(v/1000)%60;return min>=60?(min/60)+"h "+(min%60)+"m":min>0?min+"m "+sec+"s":sec>0?sec+"s":v>0?"<1s":"0s";}
    public static String format(double v,int metric){if(!known(v))return "Unavailable";if(metric==POWER||metric==BG||metric==FGPOWER)return String.format(Locale.ROOT,"%.2f mAh",v);if(metric==ALARMS||metric==JOBS)return String.format(Locale.ROOT,"%.0f",v);return time(v);}
}
