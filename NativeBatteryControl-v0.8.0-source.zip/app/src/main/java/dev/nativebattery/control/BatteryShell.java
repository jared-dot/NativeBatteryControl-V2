package dev.nativebattery.control;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.*;
import java.util.concurrent.TimeUnit;

/** Only allow-listed battery commands, no arbitrary shell or shell interpolation. */
public class BatteryShell extends IBatteryShell.Stub {
    public BatteryShell() {}
    private static void validate(String pkg) {
        if (pkg == null || !pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)*"))
            throw new IllegalArgumentException("Invalid package name");
    }
    private static boolean oneOf(String value, String... values) {
        return Arrays.asList(values).contains(value);
    }
    private static String run(String... args) { return runLimit(2097152,12,args); }
    private static String runLimit(int limit,int timeout,String... args) {
        Process p = null;
        try {
            p = new ProcessBuilder(args).redirectErrorStream(true).start();
            final Process proc = p;
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            Thread reader = new Thread(() -> {
                try (InputStream in = proc.getInputStream()) {
                    byte[] buf = new byte[4096]; int n;
                    while ((n = in.read(buf)) != -1) {
                        if (bytes.size() < limit) bytes.write(buf, 0, n);
                    }
                } catch (IOException ignored) {}
            });
            reader.start();
            if (!p.waitFor(timeout, TimeUnit.SECONDS)) {
                p.destroyForcibly(); reader.join(1000); return "ERR\nCommand timed out";
            }
            reader.join(2000);
            if (reader.isAlive()) return "ERR\nOutput read timed out";
            if (bytes.size() >= limit) return "ERR\nOutput too large to verify";
            String out = new String(bytes.toByteArray(), StandardCharsets.UTF_8).trim();
            return (p.exitValue() == 0 ? "OK\n" : "ERR\n") + out;
        } catch (Exception e) { return "ERR\n" + e; }
        finally { if (p != null) p.destroy(); }
    }
    private static String nativeSnapshot(String type,String... args){
        String raw=runLimit(8388608,25,args);if(!raw.startsWith("OK\n"))return raw;
        StringBuilder result=new StringBuilder("OK\nNative "+type+" records (selected lines, not full dump)\n");boolean section=false;int count=0;
        for(String line:raw.substring(3).split("\\R")){String t=line.trim();boolean include=false;
            if(type.equals("services"))include=t.contains("ServiceRecord{")||t.startsWith("app=")||t.startsWith("isForeground=")||t.startsWith("foregroundId=")||t.startsWith("startRequested=")||t.startsWith("foregroundServiceType=");
            else if(type.equals("processes"))include=t.contains("ProcessRecord{")||t.startsWith("curAdj=")||t.startsWith("setAdj=")||t.startsWith("curProcState=")||t.startsWith("cached=")||t.startsWith("isFrozen=");
            else {if(t.startsWith("Wake Locks:"))section=true;else if(section&&t.isEmpty())section=false;include=section||t.startsWith("mWakefulness=")||t.startsWith("mWakeLockSummary=");}
            if(include){count++;if(result.length()+line.length()>120000){result.append("\n[Output capped; additional records omitted]\n");break;}if(t.contains("ServiceRecord{")||t.contains("ProcessRecord{"))result.append('\n');result.append(line).append('\n');}
        }if(count==0)result.append("No recognized records; this Android format may differ.\n");return result.toString();
    }
    @Override public String readSetting(String pkg, String setting) {
        validate(pkg);
        switch (setting) {
            case "services": return nativeSnapshot("services","/system/bin/dumpsys","activity","services");
            case "wakelocks_now": return nativeSnapshot("wakelocks","/system/bin/dumpsys","power");
            case "processes": return nativeSnapshot("processes","/system/bin/dumpsys","activity","processes");
            case "diagnostics": {
                String battery=run("/system/bin/dumpsys","battery");
                String check=runLimit(8388608,40,"/system/bin/dumpsys","batterystats","--charged","-c");
                String human=runLimit(8388608,40,"/system/bin/dumpsys","batterystats","--charged");
                String result=BatteryDiagnostics.parse(battery,check,human).encode();
                return result.length()>200000 ? "ERR\nToo many UID records" : "OK\n"+result;
            }
            case "widgets": {
                Set<String> bound = Verification.widgets(run("/system/bin/dumpsys", "appwidget"));
                return bound == null ? "ERR\nWidget status unavailable" : "OK\n" + String.join("\n", new TreeSet<>(bound));
            }
            case "stopped": {
                String raw = run("/system/bin/dumpsys", "package", pkg);
                if (!raw.startsWith("OK\n")) return raw;
                Matcher m = Pattern.compile("(?m)^\\s*User 0:[^\\r\\n]*\\bstopped=(true|false)\\b").matcher(raw);
                return m.find() ? "OK\n stopped=" + m.group(1) : "ERR\nStopped flag unavailable";
            }
            case "buckets": return run("/system/bin/am", "get-standby-bucket", "--user", "0");
            case "whitelist": return run("/system/bin/dumpsys", "deviceidle", "whitelist");
            case "bucket": return run("/system/bin/am", "get-standby-bucket", "--user", "0", pkg);
            case "doze": {
                String raw = run("/system/bin/dumpsys", "deviceidle", "whitelist");
                if (!raw.startsWith("OK\n")) return raw;
                boolean user = false, system = false, exceptIdle = false;
                for (String line : raw.substring(3).split("\\R")) {
                    String[] fields = line.trim().split(",");
                    if (fields.length < 2 || !pkg.equals(fields[1].trim())) continue;
                    String kind = fields[0].trim();
                    if (kind.equals("user")) user = true;
                    else if (kind.equals("system")) system = true;
                    else if (kind.equals("system-excidle")) exceptIdle = true;
                }
                return "OK\n" + (system ? "System exempt (read-only)" : user ? "User exempt" : exceptIdle ? "System except-idle only" : "Not exempt");
            }
            case "appops_pair": {
                String all=run("/system/bin/cmd","appops","get","--user","0",pkg);
                String a=ToolPolicy.extractMode(all,"RUN_ANY_IN_BACKGROUND"),b=ToolPolicy.extractMode(all,"RUN_IN_BACKGROUND");
                if(a==null)a=readSetting(pkg,"RUN_ANY_IN_BACKGROUND");if(b==null)b=readSetting(pkg,"RUN_IN_BACKGROUND");
                return "OK\n"+java.util.Base64.getEncoder().encodeToString(a.getBytes(StandardCharsets.UTF_8))+"\t"+java.util.Base64.getEncoder().encodeToString(b.getBytes(StandardCharsets.UTF_8));
            }
            case "RUN_ANY_IN_BACKGROUND": case "RUN_IN_BACKGROUND":
                return run("/system/bin/cmd", "appops", "get", "--user", "0", pkg, setting);
            default: return "ERR\nUnknown setting";
        }
    }
    @Override public String writeSetting(String pkg, String setting, String value) {
        validate(pkg);
        switch (setting) {
            case "force_stop":
                if ("confirm".equals(value) && !oneOf(pkg,"android","com.android.systemui","dev.nativebattery.control","moe.shizuku.privileged.api"))
                    return run("/system/bin/am", "force-stop", "--user", "0", pkg);
                break;
            case "bucket":
                if (oneOf(value,"active","working_set","frequent","rare","restricted"))
                    return run("/system/bin/am", "set-standby-bucket", "--user", "0", pkg, value);
                break;
            case "doze":
                if (oneOf(value,"add","remove")) {
                    String current = readSetting(pkg, "doze");
                    if (!current.startsWith("OK\n") || current.contains("System exempt")) return "ERR\nSystem exemption or unreadable status; no change made";
                    return run("/system/bin/cmd", "deviceidle", "whitelist", (value.equals("add") ? "+" : "-") + pkg);
                }
                break;
            case "RUN_ANY_IN_BACKGROUND": case "RUN_IN_BACKGROUND":
                if (oneOf(value,"allow","ignore","default"))
                    return run("/system/bin/cmd", "appops", "set", "--user", "0", pkg, setting, value);
                break;
        }
        return "ERR\nUnsupported setting or value";
    }
    @Override public void destroy() { System.exit(0); }
}
