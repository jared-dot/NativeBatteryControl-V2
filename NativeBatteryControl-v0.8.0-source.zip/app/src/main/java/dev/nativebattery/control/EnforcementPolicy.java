package dev.nativebattery.control;
import java.util.*;
/** Pure allow-list and skip rules. No force stop can be stored or scheduled. */
final class EnforcementPolicy {
    static boolean valid(String p,String s,String v){if(p==null||!p.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)*")||s==null||v==null||Arrays.asList("android","com.android.systemui","dev.nativebattery.control","moe.shizuku.privileged.api").contains(p))return false;
        switch(s){case "bucket":return Arrays.asList("active","working_set","frequent","rare","restricted").contains(v);case "doze":return v.equals("add")||v.equals("remove");case "RUN_ANY_IN_BACKGROUND":case "RUN_IN_BACKGROUND":return Arrays.asList("allow","ignore","default").contains(v);default:return false;}}
    static String skip(String setting,String wanted,String actual,boolean bound){int match=Verification.compare(setting,wanted,actual);if(match==Verification.MATCH)return "Already matches";if(match==Verification.UNKNOWN)return "Unreadable — no write";if(setting.equals("doze")&&Verification.value(actual).startsWith("System exempt"))return "System exemption protected";if(setting.equals("bucket")){if(Verification.value(actual).equals("5"))return "Exempted bucket protected";if(bound&&!wanted.equals("active"))return "Bound widget protected";}return null;}
}
