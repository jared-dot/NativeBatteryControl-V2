package dev.nativebattery.control;
import java.util.Set;
public class VerificationTest {
    static int count=0;
    static void check(boolean b){count++;if(!b)throw new AssertionError("Case "+count);}
    public static void main(String[] args){
        check(Verification.compare("bucket","rare","OK\n40")==1);
        check(Verification.compare("bucket","rare","OK\n10")==0);
        check(Verification.compare("bucket","rare","OK\n5")==0);
        check(Verification.compare("bucket","rare","ERR\nPermission denied")==-1);
        check(Verification.compare("bucket","rare","OK\nError: bad package")==-1);
        check(Verification.compare("doze","remove","OK\nNot exempt")==1);
        check(Verification.compare("doze","remove","OK\nSystem exempt (read-only)")==0);
        check(Verification.compare("doze","remove","OK\nSystem except-idle only")==1);
        check(Verification.compare("doze","add","OK\nUser exempt")==1);
        check(Verification.compare("doze","add","OK\nSystem except-idle only")==0);
        check(Verification.compare("RUN_IN_BACKGROUND","allow","OK\nRUN_IN_BACKGROUND: allow")==1);
        check(Verification.compare("RUN_IN_BACKGROUND","ignore","OK\nRUN_IN_BACKGROUND: allow")==0);
        check(Verification.compare("RUN_ANY_IN_BACKGROUND","default","OK\nNo operations.\nDefault mode: allow")==1);
        check(Verification.compare("RUN_ANY_IN_BACKGROUND","allow","OK\nUid mode: RUN_ANY_IN_BACKGROUND: ignore\nRUN_ANY_IN_BACKGROUND: allow")==0);
        check(Verification.compare("RUN_ANY_IN_BACKGROUND","allow","OK\nNo operations.")==-1);
        check(Verification.compare("force_stop","confirm","OK\n stopped=true")==1);
        check(Verification.compare("force_stop","confirm","OK\n stopped=false")==0);
        check(Verification.result(true,1,0).equals("Applied, then reverted"));
        check(Verification.result(true,0,0).equals("Not applied"));
        check(Verification.result(true,0,1).equals("Applied successfully"));
        check(Verification.result(true,1,-1).equals("Could not verify"));
        check(Verification.result(false,1,1).equals("Command failed"));
        String dump="OK\nProviders:\n [0] provider ProviderId{user:0, app:10000, cmp:ComponentInfo{unused.example/.Widget}}\nWidgets:\n [0] id=17\n host=HostId{user:0, app:10001}\n provider=ProviderId{user:0, app:10002, cmp:ComponentInfo{game.frst.me.bibleversenew/.Widget}}\n [1] id=18\n provider=ProviderId{user:10, app:10002, cmp:ComponentInfo{work.example/.Widget}}\nHosts:\n";
        check(Verification.widgets(dump).equals(Set.of("game.frst.me.bibleversenew")));
        check(Verification.widgets("OK\nProviders:\nWidgets:\nHosts:\n").isEmpty());
        check(Verification.widgets("OK\nWidgets:\n provider=weird format\nHosts:\n")==null);
        check(Verification.widgets("OK\nWidgets:\n")==null);
        check(Verification.widgets("ERR\nPermission denied")==null);
        System.out.println("Passed "+count+" verification cases");
    }
}
