package dev.nativebattery.control;
public class BatteryDiagnosticsTest {
    static int tests;
    static void check(boolean ok,String msg){tests++;if(!ok)throw new AssertionError(msg);}
    static void eq(double v,double expect,String msg){check(Math.abs(v-expect)<.001,msg+": "+v);}
    public static void main(String[] args){
        String battery="OK\nCurrent Battery Service state:\n  AC powered: false\n  USB powered: false\n  Wireless powered: false\n  level: 58\n  temperature: 315\n";
        String csv="OK\n9,0,l,bt,1,36000000,12000000,45000000,18000000,1760000000000,25000000,6000000\n9,0,l,dc,40,42,31,11\n9,0,l,m,11000000,0,0,0,2500000,0,0,0,0,15000000,6,0,0,0,0,1000000,12,0,0\n9,10123,l,awl,6480000,6000000\n9,10123,l,cpu,1500000,420000,0\n9,10123,l,wua,alarm,3\n9,10123,l,wua,another,45\n9,10123,l,jb,\"job,with comma\",70000,8,60000,6\n9,10123,l,jb,job2,3000,14,3000,14\n9,10123,l,fg,720000,2\n9,10123,l,fgs,150000,1\n9,10123,l,pwi,uid,140.5\n9,10123,l,wfl,0,4000,0,1\n9,10123,u,cpu,123,234\n9,10200,l,cpu,23,40\n9,0,l,pwi,screen,100\n";
        String human="OK\nEstimated power use (mAh):\n UID u0a123: 148.0 fg: 12 bg: 126 fgs: 10 ( cpu=148 )\n UID 1000: 24.0 ( cpu=24 )\n UID u0a200: 2.3 ( cpu=2.3 )\n Uid u0a123:\n";
        BatteryDiagnostics d=BatteryDiagnostics.parse(battery,csv,human);double[] a=d.uids.get(10123);
        eq(d.device[0],58,"level");eq(d.device[1],31.5,"temperature");eq(d.device[2],36000000,"on battery");eq(d.device[3],11000000,"screen on");eq(d.device[4],25000000,"screen off");eq(d.device[5],6000000,"screen-off awake");eq(d.device[6],31,"discharge on");eq(d.device[7],11,"discharge off");eq(d.device[8],15000000,"deep doze");eq(d.device[9],2500000,"radio");eq(d.device[10],1760000000000d,"baseline");eq(d.device[11],0,"unplugged");eq(d.device[12],6,"deep entries");eq(d.device[13],12,"light entries");eq(d.device[14],1000000,"light doze");
        eq(a[0],148,"native energy");eq(a[1],126,"background energy");eq(a[2],6480000,"aggregate wake");eq(a[3],6000000,"background wake");eq(a[4],1920000,"CPU ms");eq(a[5],48,"wake alarms");eq(a[6],22,"job starts CSV quoting");eq(a[7],720000,"foreground");eq(a[8],150000,"foreground service");eq(a[9],12,"explicit foreground energy");eq(a[10],4000,"wifi scan");check(Double.isNaN(d.uids.get(10200)[1]),"missing bg not zero");check(!d.uids.containsKey(0),"exclude screen energy");check(d.uids.containsKey(1000),"system uid");
        BatteryDiagnostics round=BatteryDiagnostics.decode("OK\n"+d.encode());eq(round.uids.get(10123)[1],126,"wire roundtrip");check(Double.isNaN(round.uids.get(10200)[1]),"unknown roundtrip");check(BatteryDiagnostics.decode("ERR\nDenied").uids.isEmpty(),"failure");check(!BatteryDiagnostics.known(BatteryDiagnostics.parse("ERR\nX","ERR\nX","ERR\nX").device[0]),"missing level");check(BatteryDiagnostics.uidNumber("u10a123")==1010123,"multiuser uid");check(BatteryDiagnostics.uidNumber("u0s1000")==1000,"system uid notation");eq(BatteryDiagnostics.duration(" 2h 3m 4s 5ms (30%)"),7384005,"duration");check(BatteryDiagnostics.format(Double.NaN,0).equals("Unavailable"),"missing label");
        System.out.println(tests+" battery diagnostics cases passed");
    }
}
