package dev.nativebattery.control;
import java.util.Objects;
public class EnforcementPolicyTest {
    static int count;
    static void check(boolean b){count++;if(!b)throw new AssertionError("Case "+count);}
    public static void main(String[] args){
        String pkg="com.example.app";
        check(EnforcementPolicy.valid(pkg,"bucket","rare"));
        check(EnforcementPolicy.valid(pkg,"doze","remove"));
        check(EnforcementPolicy.valid(pkg,"RUN_ANY_IN_BACKGROUND","ignore"));
        check(EnforcementPolicy.valid(pkg,"RUN_IN_BACKGROUND","default"));
        check(!EnforcementPolicy.valid(pkg,"force_stop","confirm"));
        check(!EnforcementPolicy.valid("android","bucket","rare"));
        check(!EnforcementPolicy.valid("dev.nativebattery.control","doze","remove"));
        check(!EnforcementPolicy.valid("moe.shizuku.privileged.api","RUN_IN_BACKGROUND","ignore"));
        check(!EnforcementPolicy.valid("com.android.systemui","bucket","restricted"));
        check(!EnforcementPolicy.valid("bad;cmd","bucket","rare"));
        check(!EnforcementPolicy.valid(pkg,"bucket","5"));
        check(!EnforcementPolicy.valid(pkg,"doze","ignore"));
        check(Objects.equals(EnforcementPolicy.skip("bucket","rare","OK\n40",false),"Already matches"));
        check(Objects.equals(EnforcementPolicy.skip("bucket","rare","OK\n5",false),"Exempted bucket protected"));
        check(Objects.equals(EnforcementPolicy.skip("bucket","rare","OK\n10",true),"Bound widget protected"));
        check(EnforcementPolicy.skip("bucket","active","OK\n20",true)==null);
        check(EnforcementPolicy.skip("bucket","rare","OK\n10",false)==null);
        check(Objects.equals(EnforcementPolicy.skip("doze","remove","OK\nSystem exempt (read-only)",false),"System exemption protected"));
        check(Objects.equals(EnforcementPolicy.skip("RUN_IN_BACKGROUND","ignore","ERR\nDenied",false),"Unreadable — no write"));
        check(EnforcementPolicy.skip("RUN_IN_BACKGROUND","ignore","OK\nRUN_IN_BACKGROUND: allow",false)==null);
        check(Objects.equals(EnforcementPolicy.skip("doze","remove","OK\nNot exempt",false),"Already matches"));
        System.out.println("Passed "+count+" enforcement cases");
    }
}
