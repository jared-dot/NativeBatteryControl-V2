package dev.nativebattery.control;
import java.util.*;
public class ToolPolicyTest {
 static int tests;
 static void check(boolean ok,String msg){tests++;if(!ok)throw new AssertionError(msg);}
 public static void main(String[] args){
  String[] names={"active","working_set","frequent","rare","restricted"};String[] numbers={"10","20","30","40","45"};for(int i=0;i<5;i++)check(names[i].equals(ToolPolicy.previous("bucket","OK\n"+numbers[i])),"bucket rollback "+names[i]);
  check(ToolPolicy.previous("bucket","OK\n5")==null,"exempt bucket cannot be restored by bucket command");
  check(ToolPolicy.previous("bucket","OK\n50")==null,"never unsupported");
  check(ToolPolicy.previous("bucket","ERR\nDenied")==null,"unknown not guessed");
  check("add".equals(ToolPolicy.previous("doze","OK\nUser exempt")),"user exemption");
  check("remove".equals(ToolPolicy.previous("doze","OK\nNot exempt")),"no exemption");
  check("remove".equals(ToolPolicy.previous("doze","OK\nSystem except-idle only")),"except idle preserved");
  check(ToolPolicy.previous("doze","OK\nSystem exempt (read-only)")==null,"system exemption not writable");
  check("default".equals(ToolPolicy.previous("RUN_IN_BACKGROUND","OK\nNo operations.\nDefault mode: allow")),"default rollback");
  check("ignore".equals(ToolPolicy.previous("RUN_IN_BACKGROUND","OK\nRUN_IN_BACKGROUND: ignore")),"explicit ignore rollback");
  check(ToolPolicy.previous("RUN_IN_BACKGROUND","OK\nUid mode: RUN_IN_BACKGROUND: ignore\nRUN_IN_BACKGROUND: allow")==null,"mixed UID rollback unsafe");
  String all="OK\nUid mode: RUN_IN_BACKGROUND: ignore\nRUN_ANY_IN_BACKGROUND: allow; time=10ms\nRUN_IN_BACKGROUND: allow\nCAMERA: allow";
  check("allow".equals(Verification.mode(ToolPolicy.extractMode(all,"RUN_ANY_IN_BACKGROUND"))),"batch extraction");
  check("Mixed".equals(Verification.mode(ToolPolicy.extractMode(all,"RUN_IN_BACKGROUND"))),"batch conflicting modes preserved");
  check(ToolPolicy.extractMode("OK\nCAMERA: allow","RUN_IN_BACKGROUND")==null,"missing op needs direct fallback");
  check(ToolPolicy.extractMode("ERR\nDenied","RUN_IN_BACKGROUND")==null,"failed batch needs fallback");
  check(ToolPolicy.delta(5,12)==7,"delta");check(ToolPolicy.delta(0,0)==0,"zero delta");check(Double.isNaN(ToolPolicy.delta(8,4)),"reset counter");check(Double.isNaN(ToolPolicy.delta(Double.NaN,4)),"missing counter");
  BatteryDiagnostics a=new BatteryDiagnostics(),b=new BatteryDiagnostics();a.device[10]=b.device[10]=123456789;a.device[2]=100000;b.device[2]=3700000;a.device[3]=b.device[3]=1000;a.device[11]=b.device[11]=0;
  check(ToolPolicy.comparable(a,b,3600000,3600000),"same baseline");check(ToolPolicy.idle(a,b,3600000,3600000),"idle interval");
  b.device[3]=200000;check(!ToolPolicy.idle(a,b,3600000,3600000),"screen use excludes idle");b.device[3]=1000;b.device[11]=1;check(!ToolPolicy.idle(a,b,3600000,3600000),"charging excludes idle");b.device[11]=0;b.device[2]=200000;check(!ToolPolicy.idle(a,b,3600000,3600000),"untracked time excludes idle");b.device[2]=3700000;
  check(!ToolPolicy.comparable(a,b,3600000,3800000),"elapsed/wall mismatch");b.device[10]=567;check(!ToolPolicy.comparable(a,b,3600000,3600000),"changed baseline");b.device[10]=Double.NaN;check(!ToolPolicy.comparable(a,b,3600000,3600000),"unknown baseline");
  for(int i=0;i<3;i++)for(Map.Entry<String,String> e:ToolPolicy.preset(i).entrySet())check(EnforcementPolicy.valid("example.app",e.getKey(),e.getValue()),"preset value allowlist");
  check(!ToolPolicy.preset(0).containsKey("bucket"),"avoid conflict with exemption");check("restricted".equals(ToolPolicy.preset(2).get("bucket")),"aggressive bucket");check("working_set".equals(ToolPolicy.preset(1).get("bucket")),"balanced bucket");
  System.out.println(tests+" toolbox policy cases passed");
 }
}
