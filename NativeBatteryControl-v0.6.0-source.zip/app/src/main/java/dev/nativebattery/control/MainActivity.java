package dev.nativebattery.control;

import android.content.*;
import android.content.pm.*;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import androidx.core.graphics.ColorUtils;
import android.graphics.drawable.Drawable;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {
    private static final String[] BUCKETS={"Any bucket","Exempted (5)","Active (10)","Working Set (20)","Frequent (30)","Rare (40)","Restricted (45)","Never (50)","Other / unknown"};
    private static final String[] DOZES={"Any Doze status","Exempt","Not exempt","System except-idle only","Unknown"};
    private static final String[] BACKGROUNDS={"Any background mode","Allowed (both)","Restricted (either)","Other / unknown"};
    private static final String[] MODES={"Any mode","Allow","Ignore","Default","Other / unknown"};
    private static final String[] SETTINGS={"bucket","doze","RUN_ANY_IN_BACKGROUND","RUN_IN_BACKGROUND"};
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final List<App> apps=new ArrayList<>(), visible=new ArrayList<>();
    private final Map<String,Status> states=new HashMap<>();
    private final List<View> controls=new ArrayList<>();
    private final LinkedHashMap<String,Drawable.ConstantState> icons=new LinkedHashMap<String,Drawable.ConstantState>(64,.75f,true){protected boolean removeEldestEntry(Map.Entry<String,Drawable.ConstantState> e){return size()>80;}};
    private int ink, muted, accent, surface, outline, accentContainer, onAccentContainer;
    private LinearLayout root, home, detail, navRow;
    private ScrollView settingsScroll;
    private TextInputLayout searchInput;
    private MaterialButton appsTab, settingsTab;
    private TextView screenTitle;
    private SharedPreferences prefs;
    private boolean settingsOpen, compactCards, showPackages;
    private ScrollView detailScroll;
    private TextView connection, summary, detailLog, widgetHint, resultBanner;
    private final TextView[] sectionResult=new TextView[4];
    private final Map<String,String> lastLogs=new HashMap<>();
    private final Map<String,String[]> lastResults=new HashMap<>();
    private Set<String> boundWidgets=null;
    private TextView[] detailStatus=new TextView[4];
    private MaterialButton connect, refreshAll, exemptionList, detailRefresh;
    private TextInputEditText search;
    private MaterialCheckBox includeSystem;
    private Chip bucketFilter, dozeFilter, bgFilter, anyFilter, runFilter;
    private LinearProgressIndicator progress;
    private ListView list;
    private BaseAdapter adapter;
    private int bucketChoice,dozeChoice,bgChoice,anyChoice,runChoice,profileChoice;
    private Chip profileFilter; private TextView profileSummary,profileReport; private MaterialButton profileRun,profileMode;
    private final TextView[] desiredLabels=new TextView[4]; private boolean openingReapply;
    private static final String[] PROFILE_FILTERS={"Any profile","Saved profiles","Overridden","Matches saved","Unknown readback"};
    private App selected;
    private volatile IBatteryShell shell;
    private volatile int scanGeneration;
    private int detailGeneration;
    private volatile boolean started; private boolean binding,busy,scanning,appsReady;
    private int savedPosition,savedTop;
    private Shizuku.UserServiceArgs serviceArgs;
    private static class App {final String label,pkg;final boolean system;App(String l,String p,boolean s){label=l;pkg=p;system=s;}}
    private static class Status {
        final String[] raw; final boolean complete;
        Status(String[] r,boolean c){raw=r;complete=c;}
        String bucket(){return bucketLabel(raw[0]);}
        String doze(){return value(raw[1]);}
        String any(){return mode(raw[2]);}
        String run(){return mode(raw[3]);}
    }
    private final ServiceConnection serviceConnection=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName n,IBinder binder){if(!started)return;shell=IBatteryShell.Stub.asInterface(binder);binding=false;updateConnection();if(selected!=null)readSelected();else if(openingReapply&&Profiles.interval(MainActivity.this)==-1&&!Profiles.all(MainActivity.this).isEmpty()){openingReapply=false;reapply(false);}else scan(true);}
        @Override public void onServiceDisconnected(ComponentName n){disconnected();}
    };
    private final Shizuku.OnBinderReceivedListener received=()->runOnUiThread(()->{if(started){updateConnection();bindIfGranted();}});
    private final Shizuku.OnBinderDeadListener dead=()->runOnUiThread(this::disconnected);
    private final Shizuku.OnRequestPermissionResultListener permission=(code,result)->runOnUiThread(()->{if(code==90&&started){if(result==PackageManager.PERMISSION_GRANTED)bindIfGranted();else updateConnection();}});
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private int color(int attr){return com.google.android.material.color.MaterialColors.getColor(root,attr);}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String s,int size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);return t;}
    private TextView heading(String s,int size){TextView t=text(s,size,ink);t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private void gap(LinearLayout l,int n){l.addView(new View(this),new LinearLayout.LayoutParams(1,dp(n)));}
    private void pad(View v,int h,int vert){v.setPadding(dp(h),dp(vert),dp(h),dp(vert));}
    private ColorStateList tint(int active,int disabled){return new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled},new int[]{}},new int[]{disabled,active});}
    private int disabledInk(){return ColorUtils.blendARGB(surface,ink,.38f);}
    private int contrastText(int bg){return ColorUtils.calculateContrast(Color.BLACK,bg)>=ColorUtils.calculateContrast(Color.WHITE,bg)?Color.BLACK:Color.WHITE;}
    private int readableAccent(int seed){int target=ColorUtils.calculateLuminance(surface)>.5?Color.BLACK:Color.WHITE;for(int i=0;i<=20;i++){int c=ColorUtils.blendARGB(seed,target,i/20f);if(ColorUtils.calculateContrast(c,surface)>=4.5)return c;}return target;}
    private void loadAccent(){if(!prefs.getBoolean("dynamic",false)&&prefs.contains("accent")){int seed=prefs.getInt("accent",0xff176b60);accent=readableAccent(seed);accentContainer=ColorUtils.blendARGB(surface,accent,.17f);onAccentContainer=contrastText(accentContainer);}}
    private MaterialButton button(String s,boolean filled,View.OnClickListener listener){MaterialButton b=new MaterialButton(this,null,filled?com.google.android.material.R.attr.materialButtonStyle:com.google.android.material.R.attr.materialButtonOutlinedStyle);b.setText(s);b.setAllCaps(false);if(filled){b.setBackgroundTintList(tint(accent,ColorUtils.blendARGB(surface,ink,.12f)));b.setTextColor(tint(contrastText(accent),disabledInk()));}else{b.setTextColor(tint(accent,disabledInk()));b.setStrokeColor(tint(outline,ColorUtils.blendARGB(surface,ink,.12f)));}b.setOnClickListener(listener);return b;}
    private void weight(LinearLayout l,View v){l.addView(v,new LinearLayout.LayoutParams(0,-2,1));}
    private MaterialCardView card(){MaterialCardView c=new MaterialCardView(this);c.setRadius(dp(18));c.setCardElevation(0);c.setStrokeWidth(dp(1));c.setStrokeColor(outline);c.setCardBackgroundColor(surface);return c;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onCreate(Bundle saved){
        prefs=getSharedPreferences("appearance",MODE_PRIVATE);
        getDelegate().setLocalNightMode(prefs.getInt("theme",AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM));
        super.onCreate(saved);
        if(prefs.getBoolean("dynamic",false))DynamicColors.applyToActivityIfAvailable(this);
        compactCards=prefs.getBoolean("compact",false);showPackages=prefs.getBoolean("packages",true);
        serviceArgs=new Shizuku.UserServiceArgs(new ComponentName(this,BatteryShell.class)).daemon(false).processNameSuffix("battery_shell").tag("native_battery_ui").version(6);
        root=col();setContentView(root);ink=color(com.google.android.material.R.attr.colorOnSurface);muted=color(com.google.android.material.R.attr.colorOnSurfaceVariant);accent=color(com.google.android.material.R.attr.colorPrimary);surface=color(com.google.android.material.R.attr.colorSurface);outline=color(com.google.android.material.R.attr.colorOutlineVariant);accentContainer=color(com.google.android.material.R.attr.colorPrimaryContainer);onAccentContainer=color(com.google.android.material.R.attr.colorOnPrimaryContainer);loadAccent();root.setBackgroundColor(surface);
        LinearLayout header=col();pad(header,20,10);screenTitle=heading("Native Battery Control",22);header.addView(screenTitle);root.addView(header);
        home=col();home.setFocusableInTouchMode(true);root.addView(home,new LinearLayout.LayoutParams(-1,0,1));buildHome();
        detailScroll=new ScrollView(this);detailScroll.setFillViewport(true);detail=col();pad(detail,16,12);detailScroll.addView(detail);detailScroll.setVisibility(View.GONE);root.addView(detailScroll,new LinearLayout.LayoutParams(-1,0,1));
        settingsScroll=new ScrollView(this);settingsScroll.setFillViewport(true);settingsScroll.setVisibility(View.GONE);root.addView(settingsScroll,new LinearLayout.LayoutParams(-1,0,1));
        buildNavigation();buildSettings();
        if(saved!=null){search.setText(saved.getString("query",""));bucketChoice=saved.getInt("bucket");dozeChoice=saved.getInt("doze");bgChoice=saved.getInt("bg");anyChoice=saved.getInt("any");runChoice=saved.getInt("run");profileChoice=saved.getInt("profile");includeSystem.setChecked(saved.getBoolean("system"));updateFilters();if(saved.getBoolean("settings"))showSettings();}
        updateNav();if(!settingsOpen)home.requestFocus();
        Shizuku.addBinderReceivedListenerSticky(received);Shizuku.addBinderDeadListener(dead);Shizuku.addRequestPermissionResultListener(permission);
        worker.execute(()->{ArrayList<App> found=new ArrayList<>();PackageManager pm=getPackageManager();for(ApplicationInfo i:pm.getInstalledApplications(0)){String label;try{label=pm.getApplicationLabel(i).toString();}catch(Exception e){label=i.packageName;}found.add(new App(label,i.packageName,(i.flags&ApplicationInfo.FLAG_SYSTEM)!=0));}found.sort(Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));runOnUiThread(()->{if(isDestroyed())return;apps.addAll(found);appsReady=true;render();scan(true);});});
        updateConnection();
    }
    private void buildHome(){
        LinearLayout bar=col();pad(bar,16,4);
        // Fixed floating search surface, with a single inline refresh action.
        MaterialCardView searchPill=card();searchPill.setRadius(dp(30));searchPill.setCardElevation(dp(3));searchPill.setCardBackgroundColor(color(com.google.android.material.R.attr.colorSurfaceContainerHigh));
        LinearLayout searchRow=row();searchRow.setPadding(dp(12),0,dp(5),0);searchPill.addView(searchRow);
        ImageView magnifier=new ImageView(this);magnifier.setImageResource(R.drawable.ic_search);magnifier.setImageTintList(ColorStateList.valueOf(muted));searchRow.addView(magnifier,new LinearLayout.LayoutParams(dp(22),dp(22)));magnifier.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        searchInput=new TextInputLayout(this);searchInput.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_NONE);searchInput.setHintEnabled(false);searchInput.setEndIconMode(TextInputLayout.END_ICON_CLEAR_TEXT);searchInput.setEndIconTintList(ColorStateList.valueOf(muted));
        search=new TextInputEditText(searchInput.getContext());search.setHint("Search apps");search.setTextColor(ink);search.setHintTextColor(muted);search.setTextSize(16);search.setSingleLine(true);search.setBackground(null);search.setPadding(dp(10),0,0,0);search.setMinHeight(dp(52));search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);searchInput.addView(search,new LinearLayout.LayoutParams(-1,-2));weight(searchRow,searchInput);
        refreshAll=button("",false,v->{hideKeyboard();search.clearFocus();scan(true);});refreshAll.setIconResource(R.drawable.ic_refresh);refreshAll.setIconTint(tint(accent,disabledInk()));refreshAll.setIconSize(dp(24));refreshAll.setIconGravity(MaterialButton.ICON_GRAVITY_TEXT_START);refreshAll.setIconPadding(0);refreshAll.setStrokeWidth(0);refreshAll.setInsetTop(0);refreshAll.setInsetBottom(0);refreshAll.setMinWidth(0);refreshAll.setMinimumWidth(0);refreshAll.setPadding(0,0,0,0);refreshAll.setCornerRadius(dp(24));refreshAll.setContentDescription("Refresh all app statuses");refreshAll.setTooltipText("Refresh app statuses");searchRow.addView(refreshAll,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout.LayoutParams searchLp=new LinearLayout.LayoutParams(-1,-2);searchLp.bottomMargin=dp(9);bar.addView(searchPill,searchLp);

        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);ChipGroup chips=new ChipGroup(this);chips.setSingleLine(true);chips.setChipSpacingHorizontal(dp(6));
        dozeFilter=filterChip(chips,"Doze",DOZES,()->dozeChoice,i->dozeChoice=i);bgFilter=filterChip(chips,"Background",BACKGROUNDS,()->bgChoice,i->bgChoice=i);anyFilter=filterChip(chips,"Run any",MODES,()->anyChoice,i->anyChoice=i);runFilter=filterChip(chips,"Run",MODES,()->runChoice,i->runChoice=i);bucketFilter=filterChip(chips,"Bucket",BUCKETS,()->bucketChoice,i->bucketChoice=i);profileFilter=filterChip(chips,"Profiles",PROFILE_FILTERS,()->profileChoice,i->profileChoice=i);hs.addView(chips);bar.addView(hs);updateFilters();
        LinearLayout flags=row();includeSystem=new MaterialCheckBox(this);includeSystem.setText("System apps");includeSystem.setButtonTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{accent,muted}));weight(flags,includeSystem);MaterialButton reset=button("Clear filters",false,v->{bucketChoice=dozeChoice=bgChoice=anyChoice=runChoice=profileChoice=0;updateFilters();render();});flags.addView(reset);bar.addView(flags);
        LinearLayout statusRow=row();summary=text("Loading apps…",12,muted);weight(statusRow,summary);exemptionList=button("Doze list",false,v->showExemptions());exemptionList.setTextSize(12);exemptionList.setStrokeWidth(0);statusRow.addView(exemptionList);bar.addView(statusRow);gap(bar,6);progress=new LinearProgressIndicator(this);progress.setIndeterminate(true);progress.setIndicatorColor(accent);progress.setVisibility(View.GONE);bar.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));home.addView(bar);
        list=new ListView(this);list.setDivider(null);list.setClipToPadding(false);list.setPadding(dp(12),dp(5),dp(12),dp(12));list.setCacheColorHint(0);home.addView(list,new LinearLayout.LayoutParams(-1,0,1));adapter=new BaseAdapter(){public int getCount(){return visible.size();}public Object getItem(int pos){return visible.get(pos);}public long getItemId(int pos){return pos;}public View getView(int pos,View convert,android.view.ViewGroup parent){AppRow r=convert instanceof AppRow?(AppRow)convert:new AppRow();r.bind(visible.get(pos));return r;}};list.setAdapter(adapter);list.setOnItemClickListener((p,v,i,id)->select(visible.get(i)));
        search.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){hideKeyboard();search.clearFocus();return true;}return false;});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){render();}public void afterTextChanged(Editable e){}});
        includeSystem.setOnCheckedChangeListener((v,c)->{render();scan(false);});
    }
    private void hideKeyboard(){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);}
    private MaterialButton navButton(String label,int icon,View.OnClickListener action){
        MaterialButton b=button(label,true,action);b.setIconResource(icon);b.setIconGravity(MaterialButton.ICON_GRAVITY_TEXT_TOP);b.setIconSize(dp(20));b.setTextSize(12);b.setCornerRadius(dp(28));b.setInsetTop(0);b.setInsetBottom(0);b.setMinHeight(dp(54));b.setMinimumHeight(dp(54));b.setMinWidth(0);b.setPadding(dp(4),dp(3),dp(4),dp(3));b.setElevation(0);return b;
    }
    private void buildNavigation(){
        MaterialCardView pill=card();pill.setRadius(dp(36));pill.setCardElevation(dp(5));pill.setCardBackgroundColor(color(com.google.android.material.R.attr.colorSurfaceContainerHigh));
        navRow=row();pad(navRow,5,4);appsTab=navButton("Apps",R.drawable.ic_apps,v->showApps());settingsTab=navButton("Settings",R.drawable.ic_settings,v->showSettings());weight(navRow,appsTab);weight(navRow,settingsTab);pill.addView(navRow);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(20),dp(5),dp(20),dp(12));root.addView(pill,lp);
    }
    private void navState(MaterialButton b,boolean on){b.setBackgroundTintList(ColorStateList.valueOf(on?accentContainer:color(com.google.android.material.R.attr.colorSurfaceContainerHigh)));b.setTextColor(on?onAccentContainer:muted);b.setIconTint(ColorStateList.valueOf(on?onAccentContainer:muted));b.setSelected(on);}
    private void updateNav(){if(appsTab==null)return;navState(appsTab,!settingsOpen);navState(settingsTab,settingsOpen);screenTitle.setText(settingsOpen?"Settings":"Native Battery Control");}
    private void showApps(){if(busy){toast("A command is in progress.");return;}if(selected!=null)back();settingsOpen=false;settingsScroll.setVisibility(View.GONE);home.setVisibility(View.VISIBLE);hideKeyboard();search.clearFocus();updateNav();render();}
    private void showSettings(){if(busy){toast("A command is in progress.");return;}if(selected!=null)back();hideKeyboard();search.clearFocus();settingsOpen=true;home.setVisibility(View.GONE);detailScroll.setVisibility(View.GONE);settingsScroll.setVisibility(View.VISIBLE);updateNav();updateProfiles();}
    private void settingSwitch(LinearLayout target,String title,String description,boolean checked,CompoundButton.OnCheckedChangeListener change){MaterialSwitch sw=new MaterialSwitch(this);sw.setText(title);sw.setChecked(checked);sw.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{accent,outline}));sw.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{contrastText(accent),muted}));sw.setPadding(0,dp(6),0,dp(6));target.addView(sw);target.addView(text(description,12,muted));gap(target,12);sw.setOnCheckedChangeListener(change);}
    private void buildSettings(){LinearLayout panel=col();pad(panel,16,12);settingsScroll.addView(panel);
        buildProfileSettings(panel);gap(panel,14);
        MaterialCardView c=card();LinearLayout content=col();pad(content,16,14);c.addView(content);panel.addView(c);content.addView(heading("Appearance",19));gap(content,8);
        int[] modes={AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM,AppCompatDelegate.MODE_NIGHT_NO,AppCompatDelegate.MODE_NIGHT_YES};String[] labels={"Follow system","Light","Dark"};int current=prefs.getInt("theme",modes[0]);int index=current==modes[1]?1:current==modes[2]?2:0;
        content.addView(text("Theme",13,muted));content.addView(button(labels[index]+" ▾",false,v->new MaterialAlertDialogBuilder(this).setTitle("Appearance").setSingleChoiceItems(labels,index,(d,i)->{d.dismiss();prefs.edit().putInt("theme",modes[i]).apply();if(modes[i]!=current)getDelegate().setLocalNightMode(modes[i]);}).setNegativeButton("Cancel",null).show()));gap(content,12);
        content.addView(heading("Accent color",15));gap(content,5);
        LinearLayout colorRow=row();View currentSwatch=new View(this);currentSwatch.setBackground(swatch(accent));colorRow.addView(currentSwatch,new LinearLayout.LayoutParams(dp(32),dp(32)));TextView colorName=text(prefs.getBoolean("dynamic",false)?"Wallpaper colors":prefs.contains("accent")?hex(prefs.getInt("accent",accent)):"Default teal",14,ink);colorName.setPadding(dp(10),0,0,0);weight(colorRow,colorName);colorRow.addView(button("Customize",false,v->showColorPicker()));content.addView(colorRow);
        content.addView(text("Choose a preset or enter any hex color. Text colors adapt for readability.",12,muted));gap(content,8);
        if(DynamicColors.isDynamicColorAvailable())settingSwitch(content,"Wallpaper colors","Use Android's dynamic Material colors instead of your custom accent.",prefs.getBoolean("dynamic",false),(v,on)->{prefs.edit().putBoolean("dynamic",on).apply();recreate();});
        content.addView(button("Reset accent to default",false,v->{prefs.edit().remove("accent").putBoolean("dynamic",false).apply();recreate();}));gap(content,8);
        settingSwitch(content,"Compact app cards","Reduce spacing and use smaller app icons.",compactCards,(v,on)->{compactCards=on;prefs.edit().putBoolean("compact",on).apply();render();});
        settingSwitch(content,"Show package names","Keep package identifiers visible under app names.",showPackages,(v,on)->{showPackages=on;prefs.edit().putBoolean("packages",on).apply();render();});
        gap(panel,14);MaterialCardView access=card();LinearLayout shizuku=col();pad(shizuku,16,14);access.addView(shizuku);panel.addView(access);shizuku.addView(heading("Shizuku",19));gap(shizuku,6);connection=text("Checking Shizuku…",14,muted);shizuku.addView(connection);gap(shizuku,8);connect=button("Connect to Shizuku",true,v->connect());shizuku.addView(connect);shizuku.addView(text("Required for reading and changing native Android battery settings. No root required.",12,muted));
        gap(panel,14);MaterialCardView about=card();LinearLayout info=col();pad(info,16,14);about.addView(info);panel.addView(about);info.addView(heading("About",18));gap(info,6);info.addView(text("Native Battery Control • v0.6.0",14,ink));gap(info,5);info.addView(text("Native Android commands via Shizuku. Optional scheduled reapplication of explicitly saved settings. No automatic hibernation or scheduled force stops. Appearance settings affect only this app.",13,muted));
    }
    private void buildProfileSettings(LinearLayout panel){
        MaterialCardView c=card();LinearLayout b=col();pad(b,16,14);c.addView(b);panel.addView(c);
        b.addView(heading("Saved settings & reapply",19));gap(b,6);
        b.addView(text("Only settings you explicitly save in an app’s Change dialog are managed. Doze and background permissions are restored before standby buckets. Never force-stops apps automatically.",13,muted));gap(b,8);
        profileSummary=text("",14,ink);b.addView(profileSummary);profileMode=button("",false,v->chooseInterval());b.addView(profileMode);
        profileRun=button("Reapply all saved settings",true,v->new MaterialAlertDialogBuilder(this).setTitle("Reapply saved settings?").setMessage("Only mismatched saved settings will be written. Restrictions can delay messages or break background functions. Protected buckets are skipped.").setNegativeButton("Cancel",null).setPositiveButton("Reapply",(d,w)->reapply(true)).show());b.addView(profileRun);
        profileReport=text("",12,muted);profileReport.setTextIsSelectable(true);b.addView(profileReport);
        b.addView(button("Forget all saved settings",false,v->new MaterialAlertDialogBuilder(this).setTitle("Forget all profiles?").setMessage("Disables automatic reapplication and forgets all targets. Current device settings are not reset.").setNegativeButton("Cancel",null).setPositiveButton("Forget",(d,w)->{Profiles.setInterval(this,0);Profiles.targets(this).edit().clear().apply();updateProfiles();render();}).show()));updateProfiles();
    }
    private void chooseInterval(){int[] values={0,-1,15,30,60};String[] names={"Off — manual only","When opening the app","Every 15 minutes (approx.)","Every 30 minutes (approx.)","Every 60 minutes (approx.)"};int current=Profiles.interval(this),index=0;for(int i=0;i<values.length;i++)if(values[i]==current)index=i;new MaterialAlertDialogBuilder(this).setTitle("Automatic reapplication").setSingleChoiceItems(names,index,(d,i)->{d.dismiss();Runnable apply=()->{boolean ok=Profiles.setInterval(this,values[i]);updateProfiles();if(!ok)toast("Android rejected the schedule. Automatic reapplication is off.");};if(values[i]==0)apply.run();else new MaterialAlertDialogBuilder(this).setTitle("Enable automatic reapplication?").setMessage("Saved targets may override later manual changes. Android may delay jobs; Shizuku must be running and authorized. Notifications or services may be affected by saved restrictions. No automatic force stops.").setNegativeButton("Cancel",null).setPositiveButton("Enable",(x,y)->apply.run()).show();}).setNegativeButton("Cancel",null).show();}
    private void updateProfiles(){if(profileSummary==null||profileMode==null||profileRun==null||profileReport==null)return;Map<String,Map<String,String>> saved=Profiles.all(this);int count=0;for(Map<String,String> m:saved.values())count+=m.size();profileSummary.setText(saved.size()+" apps • "+count+" saved settings");profileMode.setText(Profiles.mode(this)+" ▾");profileMode.setEnabled(!busy);profileRun.setEnabled(shell!=null&&!busy&&count>0);profileReport.setText(Profiles.last(this));}
    private void reapply(boolean manual){if(shell==null||busy||!started)return;cancelScan();busy=true;final IBatteryShell svc=shell;final int token=++detailGeneration;updateConnection();worker.execute(()->{String result;try{result=ReapplyEngine.run(this,svc,()->started&&shell==svc&&!Thread.currentThread().isInterrupted()&&(manual||Profiles.interval(this)==-1));}catch(Exception e){result="Reapplication failed: "+e;}Profiles.record(this,result);final String report=result;runOnUiThread(()->{if(token!=detailGeneration||isDestroyed())return;busy=false;updateConnection();toast(report.split("\\n",2)[0]);scan(true);});});}
    private String profileStatus(String pkg,Status s){boolean saved=false,unknown=false,mismatch=false;for(int i=0;i<4;i++){String target=Profiles.get(this,pkg,SETTINGS[i]);if(target==null)continue;saved=true;int m=Verification.compare(SETTINGS[i],target,s==null?null:s.raw[i]);if(m==Verification.MISMATCH)mismatch=true;if(m==Verification.UNKNOWN)unknown=true;}return !saved?"":mismatch?"Saved profile • overridden":unknown?"Saved profile • readback pending":"Saved profile • matches";}
    private boolean matchesProfile(String pkg,Status s){if(profileChoice==0)return true;String status=profileStatus(pkg,s);return profileChoice==1?!status.isEmpty():profileChoice==2?status.endsWith("overridden"):profileChoice==3?status.endsWith("matches"):status.endsWith("pending");}
    private void showDesired(){if(selected==null)return;for(int i=0;i<4;i++){if(desiredLabels[i]==null)continue;String wanted=Profiles.get(this,selected.pkg,SETTINGS[i]);desiredLabels[i].setVisibility(wanted==null?View.GONE:View.VISIBLE);if(wanted!=null){String label=SETTINGS[i].equals("bucket")?bucketLabel("OK\n"+Verification.expected(SETTINGS[i],wanted)):Verification.expected(SETTINGS[i],wanted);Status s=states.get(selected.pkg);int m=Verification.compare(SETTINGS[i],wanted,s==null?null:s.raw[i]);desiredLabels[i].setText("Saved: "+label+" • "+(m==1?"matches":m==0?"overridden":"unverified"));}}}
    private static String hex(int color){return String.format(Locale.ROOT,"#%06X",color&0xffffff);}
    private GradientDrawable swatch(int c){GradientDrawable d=new GradientDrawable();d.setShape(GradientDrawable.OVAL);d.setColor(c);d.setStroke(dp(1),outline);return d;}
    private void showColorPicker(){
        LinearLayout content=col();pad(content,20,8);
        content.addView(text("Preset colors or your own hex value",14,muted));gap(content,10);
        TextInputLayout input=new TextInputLayout(this,null,com.google.android.material.R.attr.textInputOutlinedStyle);input.setHint("Hex color (#RRGGBB)");TextInputEditText field=new TextInputEditText(input.getContext());field.setSingleLine(true);field.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);input.addView(field,new LinearLayout.LayoutParams(-1,-2));
        int[] palette={0xff176b60,0xff3665c5,0xff7150ae,0xffb34175,0xffbd4e38,0xffa16a13,0xff367744,0xff566374};String[] names={"Teal","Blue","Purple","Pink","Coral","Amber","Green","Slate"};
        for(int i=0;i<palette.length;i+=4){LinearLayout line=row();for(int j=i;j<i+4;j++){final int chosen=palette[j];LinearLayout item=col();item.setGravity(Gravity.CENTER);MaterialButton sample=button("",true,v->field.setText(hex(chosen)));sample.setContentDescription(names[j]+" "+hex(chosen));sample.setMinWidth(0);sample.setMinimumWidth(0);sample.setInsetTop(0);sample.setInsetBottom(0);sample.setCornerRadius(dp(24));sample.setBackgroundTintList(ColorStateList.valueOf(chosen));item.addView(sample,new LinearLayout.LayoutParams(dp(44),dp(44)));TextView name=text(names[j],11,muted);name.setGravity(Gravity.CENTER);item.addView(name);weight(line,item);}content.addView(line);gap(content,9);}
        content.addView(input);gap(content,10);MaterialCardView preview=card();LinearLayout box=col();pad(box,12,12);TextView sampleLabel=heading("Accent preview",15);box.addView(sampleLabel);gap(box,7);MaterialButton sampleButton=button("Sample button",true,null);sampleButton.setClickable(false);box.addView(sampleButton);preview.addView(box);content.addView(preview);
        ScrollView sc=new ScrollView(this);sc.addView(content);androidx.appcompat.app.AlertDialog dialog=new MaterialAlertDialogBuilder(this).setTitle("Custom accent color").setView(sc).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        Runnable previewUpdate=()->{String raw=field.getText()==null?"":field.getText().toString().trim();boolean valid=raw.matches("#?[0-9a-fA-F]{6}");input.setError(valid?null:"Enter six hex digits");if(valid){int c=readableAccent(Color.parseColor(raw.startsWith("#")?raw:"#"+raw));sampleLabel.setTextColor(c);sampleButton.setBackgroundTintList(ColorStateList.valueOf(c));sampleButton.setTextColor(contrastText(c));}if(dialog.isShowing())dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setEnabled(valid);};
        field.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int a,int c,int f){}public void onTextChanged(CharSequence x,int a,int b,int c){previewUpdate.run();}public void afterTextChanged(Editable e){}});field.setText(hex(prefs.getInt("accent",accent)));
        dialog.setOnShowListener(d->{previewUpdate.run();dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v->{String raw=field.getText().toString().trim();if(!raw.matches("#?[0-9a-fA-F]{6}"))return;int chosen=Color.parseColor(raw.startsWith("#")?raw:"#"+raw);prefs.edit().putInt("accent",chosen).putBoolean("dynamic",false).apply();dialog.dismiss();recreate();});});dialog.show();
    }
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putBoolean("settings",settingsOpen);out.putString("query",search.getText()==null?"":search.getText().toString());out.putInt("bucket",bucketChoice);out.putInt("doze",dozeChoice);out.putInt("bg",bgChoice);out.putInt("any",anyChoice);out.putInt("run",runChoice);out.putInt("profile",profileChoice);out.putBoolean("system",includeSystem.isChecked());}
    interface GetChoice{int get();} interface SetChoice{void set(int i);}
    private Chip filterChip(ChipGroup group,String label,String[] choices,GetChoice get,SetChoice set){Chip c=new Chip(this);c.setText(label+" ▾");c.setCheckable(false);c.setOnClickListener(v->new MaterialAlertDialogBuilder(this).setTitle(label+" filter").setSingleChoiceItems(choices,get.get(),(d,i)->{set.set(i);d.dismiss();updateFilters();render();}).setNegativeButton("Cancel",null).show());group.addView(c);return c;}
    private void filterLabel(Chip c,String label,String[] values,int i){c.setText((i==0?label:label+": "+values[i])+" ▾");c.setChipBackgroundColor(ColorStateList.valueOf(i==0?surface:accentContainer));c.setTextColor(i==0?ink:onAccentContainer);c.setChipStrokeColor(ColorStateList.valueOf(outline));c.setChipStrokeWidth(dp(1));}
    private void updateFilters(){filterLabel(bucketFilter,"Bucket",BUCKETS,bucketChoice);filterLabel(dozeFilter,"Doze",DOZES,dozeChoice);filterLabel(bgFilter,"Background",BACKGROUNDS,bgChoice);filterLabel(anyFilter,"Run any",MODES,anyChoice);filterLabel(runFilter,"Run",MODES,runChoice);filterLabel(profileFilter,"Profiles",PROFILE_FILTERS,profileChoice);}
    private class AppRow extends LinearLayout {
        final ImageView icon;final TextView name,pkg;final Chip bucket,doze,background;final TextView modes;final LinearLayout inner;
        AppRow(){super(MainActivity.this);setOrientation(VERTICAL);setPadding(dp(3),dp(4),dp(3),dp(4));MaterialCardView c=card();c.setClickable(false);c.setFocusable(false);addView(c,new LinearLayout.LayoutParams(-1,-2));inner=col();pad(inner,12,10);c.addView(inner);LinearLayout top=row();icon=new ImageView(MainActivity.this);top.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout titles=col();titles.setPadding(dp(12),0,0,0);name=heading("",16);pkg=text("",11,muted);pkg.setSingleLine(true);pkg.setEllipsize(TextUtils.TruncateAt.END);titles.addView(name);titles.addView(pkg);weight(top,titles);TextView arrow=text("›",25,muted);top.addView(arrow);inner.addView(top);gap(inner,5);ChipGroup chips=new ChipGroup(MainActivity.this);chips.setChipSpacingHorizontal(dp(5));chips.setChipSpacingVertical(0);doze=tag(chips);background=tag(chips);bucket=tag(chips);inner.addView(chips);modes=text("",12,muted);inner.addView(modes);}
        void bind(App a){pad(inner,12,compactCards?5:10);int size=dp(compactCards?32:42);icon.getLayoutParams().width=size;icon.getLayoutParams().height=size;icon.requestLayout();pkg.setVisibility(showPackages?View.VISIBLE:View.GONE);name.setText(a.label);pkg.setText(a.pkg+(a.system?" • system":""));icon.setImageDrawable(appIcon(a.pkg));Status s=states.get(a.pkg);if(s==null){MainActivity.this.setTag(bucket,"Bucket · pending",false);MainActivity.this.setTag(doze,"Doze · pending",false);MainActivity.this.setTag(background,"BG · pending",false);modes.setText("Awaiting status read");}else{MainActivity.this.setTag(bucket,s.bucket(),!s.bucket().equals("Unknown"));MainActivity.this.setTag(doze,shortDoze(s.doze()),s.doze().equals("User exempt")||s.doze().startsWith("System exempt"));MainActivity.this.setTag(background,bgLabel(s),bgClass(s)==1);modes.setText("Run any: "+s.any()+"  •  Run: "+s.run()+(boundWidgets!=null&&boundWidgets.contains(a.pkg)?"\nBound widget • Android may protect bucket":""));}String profile=profileStatus(a.pkg,s);if(!profile.isEmpty())modes.append("\n"+profile);}
    }
    private Chip tag(ChipGroup group){Chip c=new Chip(this);c.setCheckable(false);c.setClickable(false);c.setFocusable(false);c.setChipMinHeight(dp(26));c.setEnsureMinTouchTargetSize(false);c.setTextSize(11);c.setChipStrokeWidth(0);group.addView(c);return c;}
    private void setTag(Chip c,String s,boolean emphasized){c.setText(s);c.setChipBackgroundColor(ColorStateList.valueOf(emphasized?accentContainer:color(com.google.android.material.R.attr.colorSurfaceVariant)));c.setTextColor(emphasized?onAccentContainer:muted);}
    private Drawable appIcon(String pkg){Drawable.ConstantState cached=icons.get(pkg);if(cached!=null)return cached.newDrawable(getResources());try{Drawable d=getPackageManager().getApplicationIcon(pkg);if(d.getConstantState()!=null)icons.put(pkg,d.getConstantState());return d;}catch(Exception e){return getPackageManager().getDefaultActivityIcon();}}
    private static String value(String raw){return raw!=null&&raw.startsWith("OK\n")?raw.substring(3).trim():"Unknown";}
    private static String bucketLabel(String raw){switch(value(raw)){case "5":return "Exempted (5)";case "10":return "Active (10)";case "20":return "Working Set (20)";case "30":return "Frequent (30)";case "40":return "Rare (40)";case "45":return "Restricted (45)";case "50":return "Never (50)";default:return value(raw).equals("Unknown")?"Unknown":"Other ("+value(raw)+")";}}
    private static String mode(String raw){return Verification.mode(raw);}
    private static boolean allowed(String m){return m.equals("allow")||m.equals("default (allow)");}
    private static boolean restricted(String m){return m.equals("ignore")||m.equals("deny")||m.equals("errored")||m.equals("default (ignore)")||m.equals("default (deny)")||m.equals("default (errored)");}
    private static int bgClass(Status s){if(s==null)return 3;if(restricted(s.any())||restricted(s.run()))return 2;if(allowed(s.any())&&allowed(s.run()))return 1;return 3;}
    private static String bgLabel(Status s){switch(bgClass(s)){case 1:return "BG allowed";case 2:return "BG restricted";default:return "BG unknown / other";}}
    private static String shortDoze(String d){if(d.equals("User exempt"))return "Doze exempt";if(d.startsWith("System exempt"))return "System exempt";if(d.equals("Not exempt"))return "Doze not exempt";if(d.equals("System except-idle only"))return "Except-idle only";return "Doze unknown";}
    private static int dozeClass(Status s){if(s==null)return 4;String d=s.doze();if(d.equals("User exempt")||d.startsWith("System exempt"))return 1;if(d.equals("Not exempt"))return 2;if(d.equals("System except-idle only"))return 3;return 4;}
    private static int modeClass(String m){if(m.equals("allow"))return 1;if(m.equals("ignore"))return 2;if(m.startsWith("default"))return 3;return 4;}
    private boolean matches(Status s){if(bucketChoice!=0){String b=s==null?"Unknown":s.bucket();if(bucketChoice==8){if(Arrays.asList(BUCKETS).subList(1,8).contains(b))return false;}else if(!BUCKETS[bucketChoice].equals(b))return false;}if(dozeChoice!=0&&dozeClass(s)!=dozeChoice)return false;if(bgChoice!=0&&bgClass(s)!=bgChoice)return false;if(anyChoice!=0&&modeClass(s==null?"Unknown":s.any())!=anyChoice)return false;if(runChoice!=0&&modeClass(s==null?"Unknown":s.run())!=runChoice)return false;return true;}
    private void render(){if(adapter==null)return;String q=search.getText()==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);int total=0,read=0;visible.clear();for(App a:apps){if(a.system&&!includeSystem.isChecked())continue;total++;Status s=states.get(a.pkg);if(s!=null&&s.complete)read++;if(!a.label.toLowerCase(Locale.ROOT).contains(q)&&!a.pkg.toLowerCase(Locale.ROOT).contains(q))continue;if(matches(s)&&matchesProfile(a.pkg,s))visible.add(a);}adapter.notifyDataSetChanged();summary.setText(visible.size()+" shown • "+read+"/"+total+" read"+(scanning?" • refreshing…":shell==null?" • offline · connect in Settings":" • snapshot")+(visible.isEmpty()?"\nNo matching apps": ""));progress.setVisibility(scanning?View.VISIBLE:View.GONE);}
    private void cancelScan(){scanGeneration++;scanning=false;}
    private void scan(boolean full){if(!started||shell==null||selected!=null||!appsReady||busy)return;cancelScan();if(full){states.clear();boundWidgets=null;}final IBatteryShell svc=shell;final int token=scanGeneration;final ArrayList<App> targets=new ArrayList<>();for(App a:apps){if(a.system&&!includeSystem.isChecked())continue;Status s=states.get(a.pkg);if(full||s==null||!s.complete)targets.add(a);}if(targets.isEmpty()){render();return;}scanning=true;render();worker.execute(()->{
        Map<String,String> buckets=new HashMap<>(),dozes=new HashMap<>();boolean whitelistOk=false;
        final Set<String> widgetSnapshot=readWidgets(svc);
        runOnUiThread(()->{if(token==scanGeneration&&!isDestroyed()){boundWidgets=widgetSnapshot;render();}});
        try{String b=svc.readSetting("android","buckets");if(b.startsWith("OK\n")){for(String line:value(b).split("\\R")){Matcher m=Pattern.compile("^\\s*([A-Za-z][A-Za-z0-9_.]*):\\s*(\\d+)\\s*$").matcher(line);if(m.matches())buckets.put(m.group(1),"OK\n"+m.group(2));}}String w=svc.readSetting("android","whitelist");whitelistOk=w.startsWith("OK\n");if(whitelistOk)for(String line:value(w).split("\\R")){String[] f=line.trim().split(",");if(f.length<2)continue;String kind=f[0].trim(),p=f[1].trim(),old=dozes.get(p);if(kind.equals("system"))dozes.put(p,"System exempt (read-only)");else if(kind.equals("user")&&(old==null||!old.startsWith("System exempt")))dozes.put(p,"User exempt");else if(kind.equals("system-excidle")&&old==null)dozes.put(p,"System except-idle only");}}catch(Exception ignored){}
        final Map<String,Status> initial=new HashMap<>();for(App a:targets){String b=buckets.get(a.pkg);String d=whitelistOk?"OK\n"+dozes.getOrDefault(a.pkg,"Not exempt"):null;initial.put(a.pkg,new Status(new String[]{b,d,null,null},false));}runOnUiThread(()->{if(token!=scanGeneration||isDestroyed())return;states.putAll(initial);render();});
        Map<String,Status> batch=new HashMap<>();int count=0;for(App a:targets){if(token!=scanGeneration||Thread.currentThread().isInterrupted())return;String[] r=initial.get(a.pkg).raw.clone();try{for(int i=0;i<4;i++){if(token!=scanGeneration)return;if(r[i]==null)r[i]=svc.readSetting(a.pkg,SETTINGS[i]);}}catch(Exception e){if(token!=scanGeneration)return;}
            batch.put(a.pkg,new Status(r,true));count++;if(batch.size()>=6||count==targets.size()){Map<String,Status> copy=new HashMap<>(batch);batch.clear();runOnUiThread(()->{if(token!=scanGeneration||isDestroyed())return;states.putAll(copy);render();});}}
        runOnUiThread(()->{if(token==scanGeneration&&!isDestroyed()){scanning=false;render();}});
    });}
    private void updateConnection(){if(connection==null)return;String s;try{if(!Shizuku.pingBinder())s="Shizuku not running";else if(Shizuku.getVersion()<12)s="Shizuku v12+ required";else if(shell!=null)s="Connected • native Android controls";else if(binding)s="Connecting…";else s="Shizuku ready • connect";}catch(Exception e){s="Shizuku unavailable";}connection.setText(s);connection.setTextColor(shell!=null?accent:muted);connect.setVisibility(shell!=null?View.GONE:View.VISIBLE);connect.setEnabled(!binding);refreshAll.setEnabled(shell!=null&&!busy);exemptionList.setEnabled(shell!=null&&!busy);if(detailRefresh!=null)detailRefresh.setEnabled(shell!=null&&!busy);for(View v:controls)v.setEnabled(shell!=null&&!busy&&selected!=null);updateProfiles();}
    private void disconnected(){shell=null;binding=false;busy=false;cancelScan();detailGeneration++;updateConnection();render();}
    private void connect(){try{if(!Shizuku.pingBinder()){toast("Start Shizuku first.");return;}if(Shizuku.getVersion()<12){toast("Update Shizuku first.");return;}if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED){if(Shizuku.shouldShowRequestPermissionRationale()){toast("Grant access in Shizuku's authorized applications.");return;}Shizuku.requestPermission(90);}else bindIfGranted();}catch(Exception e){toast(e.toString());}}
    private void bindIfGranted(){if(!started||binding||shell!=null)return;try{if(!Shizuku.pingBinder()||Shizuku.getVersion()<12||Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED)return;binding=true;updateConnection();Shizuku.bindUserService(serviceArgs,serviceConnection);}catch(Exception e){binding=false;updateConnection();toast(e.toString());}}
    @Override protected void onStart(){super.onStart();Profiles.foreground=true;openingReapply=true;started=true;updateConnection();bindIfGranted();}
    @Override protected void onStop(){Profiles.foreground=false;started=false;cancelScan();detailGeneration++;busy=false;shell=null;try{if(Shizuku.pingBinder()&&(binding||Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED))Shizuku.unbindUserService(serviceArgs,serviceConnection,true);}catch(Exception ignored){}binding=false;updateConnection();render();super.onStop();}
    @Override protected void onDestroy(){Shizuku.removeBinderReceivedListener(received);Shizuku.removeBinderDeadListener(dead);Shizuku.removeRequestPermissionResultListener(permission);worker.shutdownNow();super.onDestroy();}
    private void select(App a){if(busy)return;cancelScan();savedPosition=list.getFirstVisiblePosition();savedTop=list.getChildCount()==0?0:list.getChildAt(0).getTop();selected=a;detailGeneration++;((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);search.clearFocus();home.setVisibility(View.GONE);settingsOpen=false;settingsScroll.setVisibility(View.GONE);detailScroll.setVisibility(View.VISIBLE);updateNav();detail.removeAllViews();controls.clear();detail.addView(button("‹ All apps",false,v->back()));gap(detail,8);LinearLayout top=row();ImageView image=new ImageView(this);image.setImageDrawable(appIcon(a.pkg));top.addView(image,new LinearLayout.LayoutParams(dp(52),dp(52)));LinearLayout titles=col();titles.setPadding(dp(12),0,0,0);titles.addView(heading(a.label,23));titles.addView(text(a.pkg,12,muted));weight(top,titles);detail.addView(top);if(a.system){gap(detail,8);detail.addView(text("System app • Restrictions may break device functions.",13,accent));}gap(detail,8);widgetHint=text("Checking widget protection…",13,muted);detail.addView(widgetHint);resultBanner=heading("",15);resultBanner.setVisibility(View.GONE);detail.addView(resultBanner);gap(detail,4);detailRefresh=button("Refresh current settings",false,v->readSelected());detail.addView(detailRefresh);gap(detail,4);
        detail.addView(heading("Persistent controls",18));gap(detail,6);section(1,"Doze exemption","Full system exemptions are read-only.",new String[]{"Add exemption","Remove exemption"},new String[]{"add","remove"});section(2,"Run any activity in background","RUN_ANY_IN_BACKGROUND",new String[]{"Allow","Ignore","Default"},new String[]{"allow","ignore","default"});section(3,"Run in background","RUN_IN_BACKGROUND",new String[]{"Allow","Ignore","Default"},new String[]{"allow","ignore","default"});
        detail.addView(heading("Dynamic control",18));gap(detail,6);section(0,"Standby bucket","Android may promote apps automatically.",new String[]{"Active","Working Set","Frequent","Rare","Restricted"},new String[]{"active","working_set","frequent","rare","restricted"});
        if(!protectedStop(a.pkg)){MaterialButton stop=button("Force stop app",false,v->confirmStop());stop.setTextColor(color(com.google.android.material.R.attr.colorError));detail.addView(stop);controls.add(stop);detail.addView(text("Manual only • notifications may stop until the app is reopened.",12,muted));}else detail.addView(text("Force stop unavailable for this control / system package.",12,muted));gap(detail,12);
        if(!protectedStop(a.pkg)){MaterialButton forget=button("Forget saved settings for this app",false,v->new MaterialAlertDialogBuilder(this).setTitle("Forget saved settings?").setMessage("Stops reapplying this app’s saved settings. Current Android settings stay unchanged.").setNegativeButton("Cancel",null).setPositiveButton("Forget",(d,w)->{Profiles.forget(this,a.pkg);showDesired();updateProfiles();render();}).show());detail.addView(forget);controls.add(forget);}
        detail.addView(heading("Last command / verification",16));gap(detail,4);detailLog=text("Reading current settings…",13,muted);detailLog.setTextIsSelectable(true);detail.addView(detailLog);detail.addView(button("Copy diagnostic log",false,v->{android.content.ClipboardManager cb=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cb.setPrimaryClip(ClipData.newPlainText("Battery verification",a.pkg+"\n"+detailLog.getText()));toast("Diagnostic log copied");}));showDetail(states.get(a.pkg));showWidgetHint();showPreviousResults(a.pkg);updateConnection();if(shell!=null)readSelected();detailScroll.post(()->detailScroll.scrollTo(0,0));}
    private void section(int i,String title,String desc,String[] labels,String[] values){MaterialCardView c=card();LinearLayout box=col();pad(box,14,12);box.addView(heading(title,17));gap(box,4);detailStatus[i]=text("Reading…",15,accent);detailStatus[i].setTextIsSelectable(true);box.addView(detailStatus[i]);desiredLabels[i]=text("",12,muted);box.addView(desiredLabels[i]);sectionResult[i]=text("",13,muted);sectionResult[i].setVisibility(View.GONE);box.addView(sectionResult[i]);gap(box,4);box.addView(text(desc,12,muted));gap(box,8);MaterialButton change=button("Change",false,v->new MaterialAlertDialogBuilder(this).setTitle(title).setItems(labels,(d,which)->confirm(SETTINGS[i],values[which],labels[which])).setNegativeButton("Cancel",null).show());box.addView(change);controls.add(change);c.addView(box);detail.addView(c,new LinearLayout.LayoutParams(-1,-2));gap(detail,10);}
    private void showDetail(Status s){for(int i=0;i<4;i++)detailStatus[i].setText(s==null?"Unknown":i==0?s.bucket():i==1?s.doze():i==2?s.any():s.run());showDesired();}
    private void confirm(String setting,String value,String label){if(selected==null||shell==null||busy)return;String warning="Only this setting will change. Android or MagicOS may override it.";if((setting.equals("doze")&&value.equals("remove"))||value.equals("ignore")||value.equals("rare")||value.equals("restricted"))warning+="\n\nMay delay notifications or interrupt background services, including autofill or Android Auto.";final String pkg=selected.pkg;boolean eligible=EnforcementPolicy.valid(pkg,setting,value);LinearLayout body=col();pad(body,22,10);body.addView(text(warning,14,ink));MaterialCheckBox remember=new MaterialCheckBox(this);remember.setText("Save as desired setting for reapplication");remember.setChecked(Profiles.get(this,pkg,setting)!=null);if(eligible){gap(body,8);body.addView(remember);body.addView(text("Saved settings can be reapplied manually or automatically from Settings. Uncheck to remove this saved target.",12,muted));}new MaterialAlertDialogBuilder(this).setTitle(selected.label+": "+label).setView(body).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{if(eligible){if(remember.isChecked())Profiles.save(this,pkg,setting,value);else Profiles.remove(this,pkg,setting);showDesired();updateProfiles();}perform(setting,value);}).show();}
    private static boolean protectedStop(String pkg){return pkg.equals("android")||pkg.equals("com.android.systemui")||pkg.equals("dev.nativebattery.control")||pkg.equals("moe.shizuku.privileged.api");}
    private void confirmStop(){if(selected==null||shell==null||busy||protectedStop(selected.pkg))return;new MaterialAlertDialogBuilder(this).setTitle("Force stop "+selected.label+"?").setMessage("Android will stop this app and its services. Notifications, alarms, accessibility or other features may stop until you reopen it. This does not clear app data or guarantee a standby bucket change."+(selected.system?"\n\nSystem app: stopping it can interrupt device functions.":"")).setNegativeButton("Cancel",null).setPositiveButton("Force stop",(d,w)->perform("force_stop","confirm")).show();}
    private void readSelected(){perform(null,null);}
    private Set<String> readWidgets(IBatteryShell svc){try{String raw=svc.readSetting("android","widgets");if(raw==null||!raw.startsWith("OK\n"))return null;Set<String> found=new HashSet<>();for(String p:raw.substring(3).split("\\R")){if(!p.trim().isEmpty())found.add(p.trim());}return found;}catch(Exception e){return null;}}
    private void showWidgetHint(){if(selected==null||widgetHint==null)return;boolean bound=boundWidgets!=null&&boundWidgets.contains(selected.pkg);widgetHint.setVisibility(boundWidgets==null||bound?View.VISIBLE:View.GONE);widgetHint.setText(bound?"Bound widget detected • Android may keep this app in Active even without a Doze exemption.":"Widget protection status unavailable.");}
    private void showPreviousResults(String pkg){String[] results=lastResults.get(pkg);for(int i=0;i<4;i++){String result=results==null?null:results[i];sectionResult[i].setVisibility(result==null?View.GONE:View.VISIBLE);if(result!=null){sectionResult[i].setText("Last attempt: "+result);sectionResult[i].setTextColor(result.startsWith("Applied successfully")?accent:color(com.google.android.material.R.attr.colorError));}}String log=lastLogs.get(pkg);if(log!=null)detailLog.setText(log);}
    private static int settingIndex(String setting){for(int i=0;i<SETTINGS.length;i++)if(SETTINGS[i].equals(setting))return i;return -1;}
    private static String displayReadback(String setting,String raw){if(setting.equals("bucket"))return bucketLabel(raw);if(setting.startsWith("RUN_"))return mode(raw);return value(raw);}
    private String explanation(String setting, String requested, String raw, Status current, Set<String> widgets,String pkg){if(!setting.equals("bucket"))return setting.equals("doze")&&current.doze().startsWith("System exempt")?"Built-in full Doze exemption is read-only.":"Android reported a different or unreadable value. System policy, UID-level AppOps or MagicOS may affect it.";if(current.bucket().equals("Exempted (5)")&&(current.doze().equals("User exempt")||current.doze().startsWith("System exempt")))return "A full Doze exemption can prevent a restrictive standby bucket.";if(current.bucket().equals("Active (10)")&&widgets!=null&&widgets.contains(pkg))return "Bound widget detected: Android may enforce an Active minimum bucket.";if(current.bucket().equals("Exempted (5)"))return "Android reports Exempted (5); another system policy may protect this app.";return "Android may promote the app automatically or enforce a minimum bucket. MagicOS may also override the setting; exact cause not confirmed.";}
    private void perform(String setting,String request){
        if(shell==null||selected==null||busy)return;
        final IBatteryShell svc=shell;final String pkg=selected.pkg;final int token=++detailGeneration;final int index=settingIndex(setting);busy=true;updateConnection();
        if(setting!=null){resultBanner.setVisibility(View.VISIBLE);resultBanner.setTextColor(muted);resultBanner.setText("Applying… checking Android readback");if(index>=0){sectionResult[index].setVisibility(View.VISIBLE);sectionResult[index].setTextColor(muted);sectionResult[index].setText("Checking requested value…");}}
        worker.execute(()->{
            String[] r=new String[4];String command=null,first=null,last=null;String readError="";boolean wrote=false;
            try{
                if(setting!=null){
                    synchronized(Profiles.WRITE_LOCK){command=svc.writeSetting(pkg,setting,request);}wrote=command!=null&&command.startsWith("OK\n");
                    String key=setting.equals("force_stop")?"stopped":setting;
                    first=svc.readSetting(pkg,key);
                    final String firstText=displayReadback(setting,first);
                    runOnUiThread(()->{if(token==detailGeneration&&!isDestroyed()){resultBanner.setText("Immediate: "+firstText+" • rechecking in 5 seconds…");if(index>=0)detailStatus[index].setText(firstText);}});
                    Thread.sleep(5000);
                    last=svc.readSetting(pkg,key);
                    if(index>=0)r[index]=last;
                }
                for(int i=0;i<4;i++)if(r[i]==null)r[i]=svc.readSetting(pkg,SETTINGS[i]);
            }catch(Exception e){readError=e.toString();if(e instanceof InterruptedException)Thread.currentThread().interrupt();}
            final Set<String> widgets=readWidgets(svc);final Status status=new Status(r,true);
            final String rawCommand=command,immediate=first,delayed=last,error=readError;final boolean commandOk=wrote;
            runOnUiThread(()->{
                if(token!=detailGeneration||isDestroyed())return;
                busy=false;states.put(pkg,status);boundWidgets=widgets;showDetail(status);showWidgetHint();
                if(setting!=null){
                    int a=Verification.compare(setting,request,immediate),b=Verification.compare(setting,request,delayed);
                    String result=Verification.result(commandOk,a,b);
                    if(rawCommand==null)result="Could not verify";
                    String expected=setting.equals("bucket")?bucketLabel("OK\n"+Verification.expected(setting,request)):Verification.expected(setting,request);
                    String msg=result+"\nRequested: "+expected+"\nImmediate: "+displayReadback(setting,immediate)+"\nAfter 5 seconds: "+displayReadback(setting,delayed);
                    if(!result.equals("Applied successfully"))msg+="\n"+explanation(setting,request,delayed,status,widgets,pkg);
                    if(index>=0){String[] records=lastResults.get(pkg);if(records==null){records=new String[4];lastResults.put(pkg,records);}records[index]=msg;}
                    String log=setting+" → "+request+"\n"+msg+"\n\nCommand output: "+rawCommand+"\nImmediate raw: "+immediate+"\nDelayed raw: "+delayed+"\nWidget status: "+(widgets==null?"Unknown":widgets.contains(pkg)?"Bound":"No bound widget found")+"\nRaw Android settings: "+Arrays.toString(r)+(error.isEmpty()?"":"\nRead error: "+error);
                    lastLogs.put(pkg,log);detailLog.setText(log);resultBanner.setText(result);resultBanner.setTextColor(result.equals("Applied successfully")?accent:color(com.google.android.material.R.attr.colorError));showPreviousResults(pkg);toast(result);
                }else{showPreviousResults(pkg);if(!lastLogs.containsKey(pkg))detailLog.setText("Read only — no settings changed.\n\nRaw Android readback: "+Arrays.toString(r)+(error.isEmpty()?"":"\nRead error: "+error));}
                updateConnection();
            });
        });
    }
    private void back(){if(busy){toast("Wait for the current command to finish.");return;}detailGeneration++;selected=null;controls.clear();detailScroll.setVisibility(View.GONE);home.setVisibility(View.VISIBLE);updateNav();render();list.setSelectionFromTop(savedPosition,savedTop);updateConnection();scan(false);}
    @Override public void onBackPressed(){if(selected!=null)back();else if(settingsOpen)showApps();else super.onBackPressed();}
    private void showExemptions(){if(shell==null||busy)return;cancelScan();final IBatteryShell svc=shell;final int token=++detailGeneration;busy=true;updateConnection();render();worker.execute(()->{String raw;try{raw=svc.readSetting("android","whitelist");}catch(Exception e){raw="ERR\n"+e;}final String out=raw.startsWith("OK\n")?raw.substring(3):raw;runOnUiThread(()->{if(token!=detailGeneration||isDestroyed())return;busy=false;updateConnection();ScrollView sc=new ScrollView(this);TextView t=text(out,13,ink);pad(t,18,12);t.setTextIsSelectable(true);sc.addView(t);new MaterialAlertDialogBuilder(this).setTitle("Doze exemption list").setView(sc).setPositiveButton("Close",null).setOnDismissListener(d->scan(false)).show();});});}
}
