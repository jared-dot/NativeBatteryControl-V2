# Native Battery Control (0.2.0)

An Android UI for the native battery-related shell commands. No root required when Shizuku is started with wireless debugging. No scheduled tasks, boot receiver, force-stop, hibernation, foreground service, Internet permission or background optimization loop. The Shizuku user service is non-daemon, and the activity requests destruction when it leaves the foreground. Shizuku itself is a separate app.

## Build an APK

**GitHub (no Android SDK on your own computer):** Create an empty private repository, push all files in this directory including `.github/workflows/build.yml` to its `main` branch, and open the Actions tab. Run `Build Android APK` if it did not start automatically. On the successful run, download the `NativeBatteryControl-0.2-debug` artifact, unzip it, and install `app-debug.apk`. The workflow builds a debug-signed APK and checks its APK signature. Do not publish your signing keys. A future CI build may use a new debug signing key; it may require uninstalling this build before installing a replacement.

**Android Studio:** Open this directory as a project, install Android SDK 35 if requested, use JDK 17 and Gradle 8.9, then Build > Generate App Bundles or APKs > Generate APKs. Output: `app/build/outputs/apk/debug/app-debug.apk`. Alternatively, with SDK 35 and Gradle 8.9 installed, run `gradle :app:assembleDebug` from this directory. No wrapper is included.

## Update an existing ZIP-based GitHub repository

Upload this ZIP with the exact filename `NativeBatteryControl-source.zip` to the root of the existing repository, replacing the prior ZIP. The existing `.github/workflows/main.yml` should remain unchanged. It will extract and build the new source on commit. Download the new successful Actions artifact. If the signing key differs from your installed debug APK, uninstall only Native Battery Control and then install the new APK; Android's existing native settings are not reset by uninstalling this utility. Reauthorize Shizuku if prompted.

## What's new in 0.2.0

- Material 3 DayNight theme, app icons, outlined search and status cards.
- Standby bucket, Doze exemption, combined background status and both individual AppOps modes shown in the app list.
- Combine bucket, Doze, background and individual AppOps filters. Unknown or incomplete readings are labeled rather than assumed to be allowed.
- Bulk read of buckets and whitelist when available, with individual fallback and progressive AppOps reads. Status scan pauses when leaving the list or app; it does not run continuously in the background. Refresh to retrieve a new snapshot.
- Existing individual native writes and confirmation preserved. No new automatic changes.

## Use

1. Start Shizuku, open Native Battery Control, and tap Connect if prompted. Grant only this app access to Shizuku.
2. Search for an app. System apps are hidden until you enable Include system apps.
3. Choose exactly one setting and confirm. The screen reloads the current values after each command. No changes are made simply by opening an app or reading its settings.
4. View the native Doze exemption list using the button on the main screen. User exemptions can be added/removed individually; full system exemptions are read-only.

## Exact commands (user 0 / personal profile)

- `am get-standby-bucket --user 0 PACKAGE`
- `am set-standby-bucket --user 0 PACKAGE active|working_set|frequent|rare|restricted`
- `dumpsys deviceidle whitelist`
- `cmd deviceidle whitelist +PACKAGE` or `-PACKAGE`
- `cmd appops get --user 0 PACKAGE RUN_ANY_IN_BACKGROUND`
- `cmd appops set --user 0 PACKAGE RUN_ANY_IN_BACKGROUND allow|ignore|default`
- Same AppOps commands for `RUN_IN_BACKGROUND`.

Doze exemptions are not profile-scoped in the same way as app standby buckets. This app is intended for the primary Android user, not work profiles. AppOps modes are parsed for display, with raw readback retained in the details screen. Combined background status represents these two AppOps, not all possible Android or vendor restrictions. Android can promote buckets dynamically and MagicOS may impose separate restrictions. Changes are not periodically re-applied. No accessibility/autofill permission changes are made. Removing exemptions or choosing Rare/Restricted/Ignore can still break notifications, background playback, Android Auto or accessibility services. Start with a nonessential app and verify functionality. This does not configure PowerGenie, and the system whitelist's except-idle entries are distinct from full deep Doze exemptions.

## Build/test status

Version 0.1 was successfully built and launched on the user's Magic 8 Pro. Version 0.2 has not been compiled or device-tested in this environment; the existing GitHub workflow is required to build it. Shizuku API 13.1.5 uses its documented non-daemon UserService API. The helper accepts only explicit allow-listed commands and validated package names; no arbitrary shell interface. Compatibility with MagicOS and Android 17 remains unverified. The app targets SDK 34 and requires Android 9 or higher. This is an experimental personal utility, not a published Play Store app.
