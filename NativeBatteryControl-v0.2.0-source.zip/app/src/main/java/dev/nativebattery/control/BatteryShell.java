package dev.nativebattery.control;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/** Only allow-listed battery commands, no arbitrary shell or shell interpolation. */
public class BatteryShell extends IBatteryShell.Stub {
    public BatteryShell() {}
    private static void validate(String pkg) {
        if (pkg == null || !pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)*"))
            throw new IllegalArgumentException("Invalid package name");
    }
    private static boolean oneOf(String value, String... values) {
        return Arrays.asList(values).contains(value);
    }
    private static String run(String... args) {
        Process p = null;
        try {
            p = new ProcessBuilder(args).redirectErrorStream(true).start();
            final Process proc = p;
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            Thread reader = new Thread(() -> {
                try (InputStream in = proc.getInputStream()) {
                    byte[] buf = new byte[4096]; int n;
                    while ((n = in.read(buf)) != -1) {
                        if (bytes.size() < 262144) bytes.write(buf, 0, n);
                    }
                } catch (IOException ignored) {}
            });
            reader.start();
            if (!p.waitFor(12, TimeUnit.SECONDS)) {
                p.destroyForcibly(); reader.join(1000); return "ERR\nCommand timed out";
            }
            reader.join(2000);
            if (reader.isAlive()) return "ERR\nOutput read timed out";
            String out = new String(bytes.toByteArray(), StandardCharsets.UTF_8).trim();
            return (p.exitValue() == 0 ? "OK\n" : "ERR\n") + out;
        } catch (Exception e) { return "ERR\n" + e; }
        finally { if (p != null) p.destroy(); }
    }
    @Override public String readSetting(String pkg, String setting) {
        validate(pkg);
        switch (setting) {
            case "buckets": return run("/system/bin/am", "get-standby-bucket", "--user", "0");
            case "whitelist": return run("/system/bin/dumpsys", "deviceidle", "whitelist");
            case "bucket": return run("/system/bin/am", "get-standby-bucket", "--user", "0", pkg);
            case "doze": {
                String raw = run("/system/bin/dumpsys", "deviceidle", "whitelist");
                if (!raw.startsWith("OK\n")) return raw;
                boolean user = false, system = false, exceptIdle = false;
                for (String line : raw.substring(3).split("\\R")) {
                    String[] fields = line.trim().split(",");
                    if (fields.length < 2 || !pkg.equals(fields[1].trim())) continue;
                    String kind = fields[0].trim();
                    if (kind.equals("user")) user = true;
                    else if (kind.equals("system")) system = true;
                    else if (kind.equals("system-excidle")) exceptIdle = true;
                }
                return "OK\n" + (system ? "System exempt (read-only)" : user ? "User exempt" : exceptIdle ? "System except-idle only" : "Not exempt");
            }
            case "RUN_ANY_IN_BACKGROUND": case "RUN_IN_BACKGROUND":
                return run("/system/bin/cmd", "appops", "get", "--user", "0", pkg, setting);
            default: return "ERR\nUnknown setting";
        }
    }
    @Override public String writeSetting(String pkg, String setting, String value) {
        validate(pkg);
        switch (setting) {
            case "bucket":
                if (oneOf(value,"active","working_set","frequent","rare","restricted"))
                    return run("/system/bin/am", "set-standby-bucket", "--user", "0", pkg, value);
                break;
            case "doze":
                if (oneOf(value,"add","remove")) {
                    String current = readSetting(pkg, "doze");
                    if (!current.startsWith("OK\n") || current.contains("System exempt")) return "ERR\nSystem exemption or unreadable status; no change made";
                    return run("/system/bin/cmd", "deviceidle", "whitelist", (value.equals("add") ? "+" : "-") + pkg);
                }
                break;
            case "RUN_ANY_IN_BACKGROUND": case "RUN_IN_BACKGROUND":
                if (oneOf(value,"allow","ignore","default"))
                    return run("/system/bin/cmd", "appops", "set", "--user", "0", pkg, setting, value);
                break;
        }
        return "ERR\nUnsupported setting or value";
    }
    @Override public void destroy() { System.exit(0); }
}
