package dev.nativebattery.control;

import android.content.*;
import android.content.pm.*;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {
    private static final String[] BUCKETS={"Any bucket","Exempted (5)","Active (10)","Working Set (20)","Frequent (30)","Rare (40)","Restricted (45)","Never (50)","Other / unknown"};
    private static final String[] DOZES={"Any Doze status","Exempt","Not exempt","System except-idle only","Unknown"};
    private static final String[] BACKGROUNDS={"Any background mode","Allowed (both)","Restricted (either)","Other / unknown"};
    private static final String[] MODES={"Any mode","Allow","Ignore","Default","Other / unknown"};
    private static final String[] SETTINGS={"bucket","doze","RUN_ANY_IN_BACKGROUND","RUN_IN_BACKGROUND"};
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final List<App> apps=new ArrayList<>(), visible=new ArrayList<>();
    private final Map<String,Status> states=new HashMap<>();
    private final List<View> controls=new ArrayList<>();
    private final LinkedHashMap<String,Drawable.ConstantState> icons=new LinkedHashMap<String,Drawable.ConstantState>(64,.75f,true){protected boolean removeEldestEntry(Map.Entry<String,Drawable.ConstantState> e){return size()>80;}};
    private int ink, muted, accent, surface, outline, accentContainer, onAccentContainer;
    private LinearLayout root, home, detail;
    private ScrollView detailScroll;
    private TextView connection, summary, detailLog;
    private TextView[] detailStatus=new TextView[4];
    private MaterialButton connect, refreshAll, exemptionList, detailRefresh;
    private TextInputEditText search;
    private MaterialCheckBox includeSystem;
    private Chip bucketFilter, dozeFilter, bgFilter, anyFilter, runFilter;
    private LinearProgressIndicator progress;
    private ListView list;
    private BaseAdapter adapter;
    private int bucketChoice,dozeChoice,bgChoice,anyChoice,runChoice;
    private App selected;
    private volatile IBatteryShell shell;
    private volatile int scanGeneration;
    private int detailGeneration;
    private boolean started,binding,busy,scanning,appsReady;
    private int savedPosition,savedTop;
    private Shizuku.UserServiceArgs serviceArgs;
    private static class App {final String label,pkg;final boolean system;App(String l,String p,boolean s){label=l;pkg=p;system=s;}}
    private static class Status {
        final String[] raw; final boolean complete;
        Status(String[] r,boolean c){raw=r;complete=c;}
        String bucket(){return bucketLabel(raw[0]);}
        String doze(){return value(raw[1]);}
        String any(){return mode(raw[2]);}
        String run(){return mode(raw[3]);}
    }
    private final ServiceConnection serviceConnection=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName n,IBinder binder){if(!started)return;shell=IBatteryShell.Stub.asInterface(binder);binding=false;updateConnection();if(selected!=null)readSelected();else scan(true);}
        @Override public void onServiceDisconnected(ComponentName n){disconnected();}
    };
    private final Shizuku.OnBinderReceivedListener received=()->runOnUiThread(()->{if(started){updateConnection();bindIfGranted();}});
    private final Shizuku.OnBinderDeadListener dead=()->runOnUiThread(this::disconnected);
    private final Shizuku.OnRequestPermissionResultListener permission=(code,result)->runOnUiThread(()->{if(code==90&&started){if(result==PackageManager.PERMISSION_GRANTED)bindIfGranted();else updateConnection();}});
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private int color(int attr){return com.google.android.material.color.MaterialColors.getColor(root,attr);}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String s,int size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);return t;}
    private TextView heading(String s,int size){TextView t=text(s,size,ink);t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private void gap(LinearLayout l,int n){l.addView(new View(this),new LinearLayout.LayoutParams(1,dp(n)));}
    private void pad(View v,int h,int vert){v.setPadding(dp(h),dp(vert),dp(h),dp(vert));}
    private MaterialButton button(String s,boolean filled,View.OnClickListener listener){MaterialButton b=new MaterialButton(this,null,filled?com.google.android.material.R.attr.materialButtonStyle:com.google.android.material.R.attr.materialButtonOutlinedStyle);b.setText(s);b.setAllCaps(false);b.setOnClickListener(listener);return b;}
    private void weight(LinearLayout l,View v){l.addView(v,new LinearLayout.LayoutParams(0,-2,1));}
    private MaterialCardView card(){MaterialCardView c=new MaterialCardView(this);c.setRadius(dp(18));c.setCardElevation(0);c.setStrokeWidth(dp(1));c.setStrokeColor(outline);c.setCardBackgroundColor(surface);return c;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        serviceArgs=new Shizuku.UserServiceArgs(new ComponentName(this,BatteryShell.class)).daemon(false).processNameSuffix("battery_shell").version(2);
        root=col();setContentView(root);ink=color(com.google.android.material.R.attr.colorOnSurface);muted=color(com.google.android.material.R.attr.colorOnSurfaceVariant);accent=color(com.google.android.material.R.attr.colorPrimary);surface=color(com.google.android.material.R.attr.colorSurface);outline=color(com.google.android.material.R.attr.colorOutlineVariant);accentContainer=color(com.google.android.material.R.attr.colorPrimaryContainer);onAccentContainer=color(com.google.android.material.R.attr.colorOnPrimaryContainer);root.setBackgroundColor(surface);
        LinearLayout header=col();pad(header,16,12);header.addView(heading("Native Battery Control",24));gap(header,4);connection=text("Checking Shizuku…",13,muted);header.addView(connection);root.addView(header);
        home=col();root.addView(home,new LinearLayout.LayoutParams(-1,0,1));buildHome();
        detailScroll=new ScrollView(this);detailScroll.setFillViewport(true);detail=col();pad(detail,16,12);detailScroll.addView(detail);detailScroll.setVisibility(View.GONE);root.addView(detailScroll,new LinearLayout.LayoutParams(-1,0,1));
        Shizuku.addBinderReceivedListenerSticky(received);Shizuku.addBinderDeadListener(dead);Shizuku.addRequestPermissionResultListener(permission);
        worker.execute(()->{ArrayList<App> found=new ArrayList<>();PackageManager pm=getPackageManager();for(ApplicationInfo i:pm.getInstalledApplications(0)){String label;try{label=pm.getApplicationLabel(i).toString();}catch(Exception e){label=i.packageName;}found.add(new App(label,i.packageName,(i.flags&ApplicationInfo.FLAG_SYSTEM)!=0));}found.sort(Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));runOnUiThread(()->{if(isDestroyed())return;apps.addAll(found);appsReady=true;render();scan(true);});});
        updateConnection();
    }
    private void buildHome(){
        LinearLayout bar=col();pad(bar,16,4);
        connect=button("Connect to Shizuku",true,v->connect());bar.addView(connect);
        LinearLayout actions=row();refreshAll=button("Refresh status",false,v->scan(true));exemptionList=button("Doze list",false,v->showExemptions());weight(actions,refreshAll);View spacer=new View(this);actions.addView(spacer,new LinearLayout.LayoutParams(dp(8),1));weight(actions,exemptionList);bar.addView(actions);
        TextInputLayout input=new TextInputLayout(this,null,com.google.android.material.R.attr.textInputOutlinedStyle);input.setHint("Search apps or packages");input.setEndIconMode(TextInputLayout.END_ICON_CLEAR_TEXT);search=new TextInputEditText(input.getContext());search.setSingleLine(true);input.addView(search,new LinearLayout.LayoutParams(-1,-2));bar.addView(input);gap(bar,5);
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);ChipGroup chips=new ChipGroup(this);chips.setSingleLine(true);chips.setChipSpacingHorizontal(dp(6));
        bucketFilter=filterChip(chips,"Bucket",BUCKETS,()->bucketChoice,i->bucketChoice=i);dozeFilter=filterChip(chips,"Doze",DOZES,()->dozeChoice,i->dozeChoice=i);bgFilter=filterChip(chips,"Background",BACKGROUNDS,()->bgChoice,i->bgChoice=i);anyFilter=filterChip(chips,"Run any",MODES,()->anyChoice,i->anyChoice=i);runFilter=filterChip(chips,"Run",MODES,()->runChoice,i->runChoice=i);hs.addView(chips);bar.addView(hs);updateFilters();
        LinearLayout flags=row();includeSystem=new MaterialCheckBox(this);includeSystem.setText("System apps");weight(flags,includeSystem);MaterialButton reset=button("Clear filters",false,v->{bucketChoice=dozeChoice=bgChoice=anyChoice=runChoice=0;updateFilters();render();});flags.addView(reset);bar.addView(flags);
        summary=text("Loading apps…",12,muted);bar.addView(summary);gap(bar,6);progress=new LinearProgressIndicator(this);progress.setIndeterminate(true);progress.setVisibility(View.GONE);bar.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));home.addView(bar);
        list=new ListView(this);list.setDivider(null);list.setClipToPadding(false);list.setPadding(dp(12),dp(5),dp(12),dp(12));list.setCacheColorHint(0);home.addView(list,new LinearLayout.LayoutParams(-1,0,1));adapter=new BaseAdapter(){public int getCount(){return visible.size();}public Object getItem(int pos){return visible.get(pos);}public long getItemId(int pos){return pos;}public View getView(int pos,View convert,android.view.ViewGroup parent){AppRow r=convert instanceof AppRow?(AppRow)convert:new AppRow();r.bind(visible.get(pos));return r;}};list.setAdapter(adapter);list.setOnItemClickListener((p,v,i,id)->select(visible.get(i)));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){render();}public void afterTextChanged(Editable e){}});
        includeSystem.setOnCheckedChangeListener((v,c)->{render();scan(false);});
    }
    interface GetChoice{int get();} interface SetChoice{void set(int i);}
    private Chip filterChip(ChipGroup group,String label,String[] choices,GetChoice get,SetChoice set){Chip c=new Chip(this);c.setText(label+" ▾");c.setCheckable(false);c.setOnClickListener(v->new MaterialAlertDialogBuilder(this).setTitle(label+" filter").setSingleChoiceItems(choices,get.get(),(d,i)->{set.set(i);d.dismiss();updateFilters();render();}).setNegativeButton("Cancel",null).show());group.addView(c);return c;}
    private void filterLabel(Chip c,String label,String[] values,int i){c.setText((i==0?label:label+": "+values[i])+" ▾");c.setChipBackgroundColor(ColorStateList.valueOf(i==0?surface:accentContainer));c.setTextColor(i==0?ink:onAccentContainer);c.setChipStrokeColor(ColorStateList.valueOf(outline));c.setChipStrokeWidth(dp(1));}
    private void updateFilters(){filterLabel(bucketFilter,"Bucket",BUCKETS,bucketChoice);filterLabel(dozeFilter,"Doze",DOZES,dozeChoice);filterLabel(bgFilter,"Background",BACKGROUNDS,bgChoice);filterLabel(anyFilter,"Run any",MODES,anyChoice);filterLabel(runFilter,"Run",MODES,runChoice);}
    private class AppRow extends LinearLayout {
        final ImageView icon;final TextView name,pkg;final Chip bucket,doze,background;final TextView modes;
        AppRow(){super(MainActivity.this);setOrientation(VERTICAL);setPadding(dp(3),dp(4),dp(3),dp(4));MaterialCardView c=card();c.setClickable(false);c.setFocusable(false);addView(c,new LinearLayout.LayoutParams(-1,-2));LinearLayout inner=col();pad(inner,12,10);c.addView(inner);LinearLayout top=row();icon=new ImageView(MainActivity.this);top.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout titles=col();titles.setPadding(dp(12),0,0,0);name=heading("",16);pkg=text("",11,muted);pkg.setSingleLine(true);pkg.setEllipsize(TextUtils.TruncateAt.END);titles.addView(name);titles.addView(pkg);weight(top,titles);TextView arrow=text("›",25,muted);top.addView(arrow);inner.addView(top);gap(inner,5);ChipGroup chips=new ChipGroup(MainActivity.this);chips.setChipSpacingHorizontal(dp(5));chips.setChipSpacingVertical(0);bucket=tag(chips);doze=tag(chips);background=tag(chips);inner.addView(chips);modes=text("",12,muted);inner.addView(modes);}
        void bind(App a){name.setText(a.label);pkg.setText(a.pkg+(a.system?" • system":""));icon.setImageDrawable(appIcon(a.pkg));Status s=states.get(a.pkg);if(s==null){MainActivity.this.setTag(bucket,"Bucket · pending",false);MainActivity.this.setTag(doze,"Doze · pending",false);MainActivity.this.setTag(background,"BG · pending",false);modes.setText("Awaiting status read");}else{MainActivity.this.setTag(bucket,s.bucket(),!s.bucket().equals("Unknown"));MainActivity.this.setTag(doze,shortDoze(s.doze()),s.doze().equals("User exempt")||s.doze().startsWith("System exempt"));MainActivity.this.setTag(background,bgLabel(s),bgClass(s)==1);modes.setText("Run any: "+s.any()+"  •  Run: "+s.run());}}
    }
    private Chip tag(ChipGroup group){Chip c=new Chip(this);c.setCheckable(false);c.setClickable(false);c.setFocusable(false);c.setChipMinHeight(dp(26));c.setEnsureMinTouchTargetSize(false);c.setTextSize(11);c.setChipStrokeWidth(0);group.addView(c);return c;}
    private void setTag(Chip c,String s,boolean emphasized){c.setText(s);c.setChipBackgroundColor(ColorStateList.valueOf(emphasized?accentContainer:color(com.google.android.material.R.attr.colorSurfaceVariant)));c.setTextColor(emphasized?onAccentContainer:muted);}
    private Drawable appIcon(String pkg){Drawable.ConstantState cached=icons.get(pkg);if(cached!=null)return cached.newDrawable(getResources());try{Drawable d=getPackageManager().getApplicationIcon(pkg);if(d.getConstantState()!=null)icons.put(pkg,d.getConstantState());return d;}catch(Exception e){return getPackageManager().getDefaultActivityIcon();}}
    private static String value(String raw){return raw!=null&&raw.startsWith("OK\n")?raw.substring(3).trim():"Unknown";}
    private static String bucketLabel(String raw){switch(value(raw)){case "5":return "Exempted (5)";case "10":return "Active (10)";case "20":return "Working Set (20)";case "30":return "Frequent (30)";case "40":return "Rare (40)";case "45":return "Restricted (45)";case "50":return "Never (50)";default:return value(raw).equals("Unknown")?"Unknown":"Other ("+value(raw)+")";}}
    private static String mode(String raw){String v=value(raw);if(v.equals("Unknown"))return v;Matcher m=Pattern.compile("(?im)^\\s*(?:Uid mode:\\s*)?(?:RUN_ANY_IN_BACKGROUND|RUN_IN_BACKGROUND):\\s*([a-z_]+)").matcher(v);String first=null;while(m.find()){String found=m.group(1);if(first==null)first=found;else if(!first.equals(found))return "Mixed";}if(first!=null)return first;Matcher def=Pattern.compile("(?i)Default mode:\\s*([a-z_]+)").matcher(v);return def.find()?"default ("+def.group(1)+")":"Unknown";}
    private static boolean allowed(String m){return m.equals("allow")||m.equals("default (allow)");}
    private static boolean restricted(String m){return m.equals("ignore")||m.equals("deny")||m.equals("errored")||m.equals("default (ignore)")||m.equals("default (deny)")||m.equals("default (errored)");}
    private static int bgClass(Status s){if(s==null)return 3;if(restricted(s.any())||restricted(s.run()))return 2;if(allowed(s.any())&&allowed(s.run()))return 1;return 3;}
    private static String bgLabel(Status s){switch(bgClass(s)){case 1:return "BG allowed";case 2:return "BG restricted";default:return "BG unknown / other";}}
    private static String shortDoze(String d){if(d.equals("User exempt"))return "Doze exempt";if(d.startsWith("System exempt"))return "System exempt";if(d.equals("Not exempt"))return "Doze not exempt";if(d.equals("System except-idle only"))return "Except-idle only";return "Doze unknown";}
    private static int dozeClass(Status s){if(s==null)return 4;String d=s.doze();if(d.equals("User exempt")||d.startsWith("System exempt"))return 1;if(d.equals("Not exempt"))return 2;if(d.equals("System except-idle only"))return 3;return 4;}
    private static int modeClass(String m){if(m.equals("allow"))return 1;if(m.equals("ignore"))return 2;if(m.startsWith("default"))return 3;return 4;}
    private boolean matches(Status s){if(bucketChoice!=0){String b=s==null?"Unknown":s.bucket();if(bucketChoice==8){if(Arrays.asList(BUCKETS).subList(1,8).contains(b))return false;}else if(!BUCKETS[bucketChoice].equals(b))return false;}if(dozeChoice!=0&&dozeClass(s)!=dozeChoice)return false;if(bgChoice!=0&&bgClass(s)!=bgChoice)return false;if(anyChoice!=0&&modeClass(s==null?"Unknown":s.any())!=anyChoice)return false;if(runChoice!=0&&modeClass(s==null?"Unknown":s.run())!=runChoice)return false;return true;}
    private void render(){if(adapter==null)return;String q=search.getText()==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);int total=0,read=0;visible.clear();for(App a:apps){if(a.system&&!includeSystem.isChecked())continue;total++;Status s=states.get(a.pkg);if(s!=null&&s.complete)read++;if(!a.label.toLowerCase(Locale.ROOT).contains(q)&&!a.pkg.toLowerCase(Locale.ROOT).contains(q))continue;if(matches(s))visible.add(a);}adapter.notifyDataSetChanged();summary.setText(visible.size()+" shown • "+read+"/"+total+" read"+(scanning?" • refreshing…":shell==null?" • offline / cached":" • snapshot")+(visible.isEmpty()?"\nNo matching apps": ""));progress.setVisibility(scanning?View.VISIBLE:View.GONE);}
    private void cancelScan(){scanGeneration++;scanning=false;}
    private void scan(boolean full){if(!started||shell==null||selected!=null||!appsReady||busy)return;cancelScan();if(full)states.clear();final IBatteryShell svc=shell;final int token=scanGeneration;final ArrayList<App> targets=new ArrayList<>();for(App a:apps){if(a.system&&!includeSystem.isChecked())continue;Status s=states.get(a.pkg);if(full||s==null||!s.complete)targets.add(a);}if(targets.isEmpty()){render();return;}scanning=true;render();worker.execute(()->{
        Map<String,String> buckets=new HashMap<>(),dozes=new HashMap<>();boolean whitelistOk=false;
        try{String b=svc.readSetting("android","buckets");if(b.startsWith("OK\n")){for(String line:value(b).split("\\R")){Matcher m=Pattern.compile("^\\s*([A-Za-z][A-Za-z0-9_.]*):\\s*(\\d+)\\s*$").matcher(line);if(m.matches())buckets.put(m.group(1),"OK\n"+m.group(2));}}String w=svc.readSetting("android","whitelist");whitelistOk=w.startsWith("OK\n");if(whitelistOk)for(String line:value(w).split("\\R")){String[] f=line.trim().split(",");if(f.length<2)continue;String kind=f[0].trim(),p=f[1].trim(),old=dozes.get(p);if(kind.equals("system"))dozes.put(p,"System exempt (read-only)");else if(kind.equals("user")&&(old==null||!old.startsWith("System exempt")))dozes.put(p,"User exempt");else if(kind.equals("system-excidle")&&old==null)dozes.put(p,"System except-idle only");}}catch(Exception ignored){}
        final Map<String,Status> initial=new HashMap<>();for(App a:targets){String b=buckets.get(a.pkg);String d=whitelistOk?"OK\n"+dozes.getOrDefault(a.pkg,"Not exempt"):null;initial.put(a.pkg,new Status(new String[]{b,d,null,null},false));}runOnUiThread(()->{if(token!=scanGeneration||isDestroyed())return;states.putAll(initial);render();});
        Map<String,Status> batch=new HashMap<>();int count=0;for(App a:targets){if(token!=scanGeneration||Thread.currentThread().isInterrupted())return;String[] r=initial.get(a.pkg).raw.clone();try{for(int i=0;i<4;i++){if(token!=scanGeneration)return;if(r[i]==null)r[i]=svc.readSetting(a.pkg,SETTINGS[i]);}}catch(Exception e){if(token!=scanGeneration)return;}
            batch.put(a.pkg,new Status(r,true));count++;if(batch.size()>=6||count==targets.size()){Map<String,Status> copy=new HashMap<>(batch);batch.clear();runOnUiThread(()->{if(token!=scanGeneration||isDestroyed())return;states.putAll(copy);render();});}}
        runOnUiThread(()->{if(token==scanGeneration&&!isDestroyed()){scanning=false;render();}});
    });}
    private void updateConnection(){if(connection==null)return;String s;try{if(!Shizuku.pingBinder())s="Shizuku not running";else if(Shizuku.getVersion()<12)s="Shizuku v12+ required";else if(shell!=null)s="Connected • native Android controls";else if(binding)s="Connecting…";else s="Shizuku ready • connect";}catch(Exception e){s="Shizuku unavailable";}connection.setText(s);connection.setTextColor(shell!=null?accent:muted);connect.setVisibility(shell!=null?View.GONE:View.VISIBLE);connect.setEnabled(!binding);refreshAll.setEnabled(shell!=null&&!busy);exemptionList.setEnabled(shell!=null&&!busy);if(detailRefresh!=null)detailRefresh.setEnabled(shell!=null&&!busy);for(View v:controls)v.setEnabled(shell!=null&&!busy&&selected!=null);}
    private void disconnected(){shell=null;binding=false;busy=false;cancelScan();detailGeneration++;updateConnection();render();}
    private void connect(){try{if(!Shizuku.pingBinder()){toast("Start Shizuku first.");return;}if(Shizuku.getVersion()<12){toast("Update Shizuku first.");return;}if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED){if(Shizuku.shouldShowRequestPermissionRationale()){toast("Grant access in Shizuku's authorized applications.");return;}Shizuku.requestPermission(90);}else bindIfGranted();}catch(Exception e){toast(e.toString());}}
    private void bindIfGranted(){if(!started||binding||shell!=null)return;try{if(!Shizuku.pingBinder()||Shizuku.getVersion()<12||Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED)return;binding=true;updateConnection();Shizuku.bindUserService(serviceArgs,serviceConnection);}catch(Exception e){binding=false;updateConnection();toast(e.toString());}}
    @Override protected void onStart(){super.onStart();started=true;updateConnection();bindIfGranted();}
    @Override protected void onStop(){started=false;cancelScan();detailGeneration++;busy=false;shell=null;try{if(Shizuku.pingBinder()&&(binding||Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED))Shizuku.unbindUserService(serviceArgs,serviceConnection,true);}catch(Exception ignored){}binding=false;updateConnection();render();super.onStop();}
    @Override protected void onDestroy(){Shizuku.removeBinderReceivedListener(received);Shizuku.removeBinderDeadListener(dead);Shizuku.removeRequestPermissionResultListener(permission);worker.shutdownNow();super.onDestroy();}
    private void select(App a){if(busy)return;cancelScan();savedPosition=list.getFirstVisiblePosition();savedTop=list.getChildCount()==0?0:list.getChildAt(0).getTop();selected=a;detailGeneration++;((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);search.clearFocus();home.setVisibility(View.GONE);detailScroll.setVisibility(View.VISIBLE);detail.removeAllViews();controls.clear();detail.addView(button("‹ All apps",false,v->back()));gap(detail,8);LinearLayout top=row();ImageView image=new ImageView(this);image.setImageDrawable(appIcon(a.pkg));top.addView(image,new LinearLayout.LayoutParams(dp(52),dp(52)));LinearLayout titles=col();titles.setPadding(dp(12),0,0,0);titles.addView(heading(a.label,23));titles.addView(text(a.pkg,12,muted));weight(top,titles);detail.addView(top);if(a.system){gap(detail,8);detail.addView(text("System app • Restrictions may break device functions.",13,accent));}gap(detail,8);detailRefresh=button("Refresh current settings",false,v->readSelected());detail.addView(detailRefresh);gap(detail,8);
        section(0,"Standby bucket","Android may promote apps automatically.",new String[]{"Active","Working Set","Frequent","Rare","Restricted"},new String[]{"active","working_set","frequent","rare","restricted"});section(1,"Doze exemption","Full system exemptions are read-only.",new String[]{"Add exemption","Remove exemption"},new String[]{"add","remove"});section(2,"Run any activity in background","RUN_ANY_IN_BACKGROUND",new String[]{"Allow","Ignore","Default"},new String[]{"allow","ignore","default"});section(3,"Run in background","RUN_IN_BACKGROUND",new String[]{"Allow","Ignore","Default"},new String[]{"allow","ignore","default"});
        detail.addView(heading("Last command / verification",16));gap(detail,4);detailLog=text("Reading current settings…",13,muted);detailLog.setTextIsSelectable(true);detail.addView(detailLog);showDetail(states.get(a.pkg));updateConnection();if(shell!=null)readSelected();detailScroll.post(()->detailScroll.scrollTo(0,0));}
    private void section(int i,String title,String desc,String[] labels,String[] values){MaterialCardView c=card();LinearLayout box=col();pad(box,14,12);box.addView(heading(title,17));gap(box,4);detailStatus[i]=text("Reading…",15,accent);detailStatus[i].setTextIsSelectable(true);box.addView(detailStatus[i]);gap(box,4);box.addView(text(desc,12,muted));gap(box,8);MaterialButton change=button("Change",false,v->new MaterialAlertDialogBuilder(this).setTitle(title).setItems(labels,(d,which)->confirm(SETTINGS[i],values[which],labels[which])).setNegativeButton("Cancel",null).show());box.addView(change);controls.add(change);c.addView(box);detail.addView(c,new LinearLayout.LayoutParams(-1,-2));gap(detail,10);}
    private void showDetail(Status s){for(int i=0;i<4;i++)detailStatus[i].setText(s==null?"Unknown":i==0?s.bucket():i==1?s.doze():i==2?s.any():s.run());}
    private void confirm(String setting,String value,String label){if(selected==null||shell==null||busy)return;String warning="Only this setting will change. Android or MagicOS may override it.";if((setting.equals("doze")&&value.equals("remove"))||value.equals("ignore")||value.equals("rare")||value.equals("restricted"))warning+="\n\nMay delay notifications or interrupt background services, including autofill or Android Auto.";new MaterialAlertDialogBuilder(this).setTitle(selected.label+": "+label).setMessage(warning).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->perform(setting,value)).show();}
    private void readSelected(){perform(null,null);}
    private void perform(String setting,String value){if(shell==null||selected==null||busy)return;final IBatteryShell svc=shell;final String pkg=selected.pkg;final int token=++detailGeneration;busy=true;updateConnection();worker.execute(()->{String[] r=new String[4];String outcome="Read only — no settings changed.";try{if(setting!=null){String raw=svc.writeSetting(pkg,setting,value);outcome=setting+" → "+value+"\n"+(raw.equals("OK\n")?"Command returned success; check readback.":raw);}for(int i=0;i<4;i++)r[i]=svc.readSetting(pkg,SETTINGS[i]);}catch(Exception e){outcome+="\nConnection / command error: "+e;}final String message=outcome;runOnUiThread(()->{if(token!=detailGeneration||isDestroyed())return;busy=false;Status s=new Status(r,true);states.put(pkg,s);showDetail(s);detailLog.setText(message+"\n\nRaw Android readback:\n"+Arrays.toString(r));updateConnection();});});}
    private void back(){if(busy){toast("Wait for the current command to finish.");return;}detailGeneration++;selected=null;controls.clear();detailScroll.setVisibility(View.GONE);home.setVisibility(View.VISIBLE);render();list.setSelectionFromTop(savedPosition,savedTop);updateConnection();scan(false);}
    @Override public void onBackPressed(){if(selected!=null)back();else super.onBackPressed();}
    private void showExemptions(){if(shell==null||busy)return;cancelScan();final IBatteryShell svc=shell;final int token=++detailGeneration;busy=true;updateConnection();render();worker.execute(()->{String raw;try{raw=svc.readSetting("android","whitelist");}catch(Exception e){raw="ERR\n"+e;}final String out=raw.startsWith("OK\n")?raw.substring(3):raw;runOnUiThread(()->{if(token!=detailGeneration||isDestroyed())return;busy=false;updateConnection();ScrollView sc=new ScrollView(this);TextView t=text(out,13,ink);pad(t,18,12);t.setTextIsSelectable(true);sc.addView(t);new MaterialAlertDialogBuilder(this).setTitle("Doze exemption list").setView(sc).setPositiveButton("Close",null).setOnDismissListener(d->scan(false)).show();});});}
}
